<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/get_profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.get_profile',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/edit_profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.edit_profile',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/forgotPassword' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.forgotPassword',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/get_task' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.get_task',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/get_task_detail' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.get_task_detail',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/save_task' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.save_task',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3ldVBEVYgMo5cgZJ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.submitlogin',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel/manageuser' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.user.manage',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel/adduser' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.user.add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.user.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel/edituser' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.user.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel/searchuser' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.user.search',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel/managemanager' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.manager.manage',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel/addmanager' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.manager.add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.manager.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel/editmanager' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.manager.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel/searchmanager' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.manager.search',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel/managecategory' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.category.manage',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel/addcategory' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.category.add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.category.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel/editcategory' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.category.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel/searchcategory' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.category.search',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel/managejob' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.job.manage',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel/addjob' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.job.add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.job.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel/editjob' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.job.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminpanel/searchjob' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.job.search',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.submitlogin',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel/manageuser' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.user.manage',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel/adduser' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.user.add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.user.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel/edituser' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.user.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel/searchuser' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.user.search',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel/managemanager' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.manager.manage',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel/addmanager' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.manager.add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.manager.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel/editmanager' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.manager.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel/searchmanager' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.manager.search',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel/managecategory' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.category.manage',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel/addcategory' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.category.add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.category.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel/editcategory' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.category.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel/searchcategory' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.category.search',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel/managejob' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.job.manage',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel/addjob' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.job.add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.job.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel/editjob' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.job.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/managerpanel/searchjob' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.job.search',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/adminpanel/(?|edit(?|user/([^/]++)(*:42)|manager/([^/]++)(*:65)|category/([^/]++)(*:89)|job/([^/]++)(*:108))|delete(?|user/([^/]++)(*:139)|manager/([^/]++)(*:163)|category/([^/]++)(*:188)|job/([^/]++)(*:208))|ajaxgetuser/([^/]++)(*:237)|viewjob/([^/]++)(*:261))|/managerpanel/(?|edit(?|user/([^/]++)(*:307)|manager/([^/]++)(*:331)|category/([^/]++)(*:356)|job/([^/]++)(*:376))|delete(?|user/([^/]++)(*:407)|manager/([^/]++)(*:431)|category/([^/]++)(*:456)|job/([^/]++)(*:476))|ajaxgetuser/([^/]++)(*:505)|viewjob/([^/]++)(*:529)))/?$}sDu',
    ),
    3 => 
    array (
      42 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.user.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      65 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.manager.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      89 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.category.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      108 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.job.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      139 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.user.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      163 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.manager.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      188 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.category.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      208 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.job.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      237 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.job.ajaxgetuser',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      261 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminpanel.job.view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      307 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.user.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      331 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.manager.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      356 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.category.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      376 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.job.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      407 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.user.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      431 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.manager.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      456 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.category.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      476 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.job.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      505 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.job.ajaxgetuser',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      529 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'managerpanel.job.view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'api.' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:api',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":289:{@JH/lgCx37KBJsydPqbt6QgXRe5fx1T//WBNO8bhyDrw=.a:5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000484e713d00000000022fba2d";}}',
        'as' => 'api.',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'api.login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserController@login',
        'controller' => 'App\\Http\\Controllers\\API\\UserController@login',
        'as' => 'api.login',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'api.logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserController@Logout',
        'controller' => 'App\\Http\\Controllers\\API\\UserController@Logout',
        'as' => 'api.logout',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'api.get_profile' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/get_profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserController@get_profile',
        'controller' => 'App\\Http\\Controllers\\API\\UserController@get_profile',
        'as' => 'api.get_profile',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'api.edit_profile' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/edit_profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserController@edit_profile',
        'controller' => 'App\\Http\\Controllers\\API\\UserController@edit_profile',
        'as' => 'api.edit_profile',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'api.forgotPassword' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/forgotPassword',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserController@forgotPassword',
        'controller' => 'App\\Http\\Controllers\\API\\UserController@forgotPassword',
        'as' => 'api.forgotPassword',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'api.get_task' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/get_task',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\JobController@get_task',
        'controller' => 'App\\Http\\Controllers\\API\\JobController@get_task',
        'as' => 'api.get_task',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'api.get_task_detail' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/get_task_detail',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\JobController@get_task_detail',
        'controller' => 'App\\Http\\Controllers\\API\\JobController@get_task_detail',
        'as' => 'api.get_task_detail',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'api.save_task' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/save_task',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\JobController@save_task',
        'controller' => 'App\\Http\\Controllers\\API\\JobController@save_task',
        'as' => 'api.save_task',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3ldVBEVYgMo5cgZJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":256:{@1puwqu6OTdNgIVhdx1swZCZZB/c3FEmGbKxaEaG5CnA=.a:5:{s:3:"use";a:0:{}s:8:"function";s:44:"function () {
    return \\view(\'welcome\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000484e710300000000022fba2d";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::3ldVBEVYgMo5cgZJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":261:{@Y8cS+nQrLRKUrh/gAlaCgnYgCjns2lzSgrHxl9F8EwA=.a:5:{s:3:"use";a:0:{}s:8:"function";s:49:"function () {
    return \\redirect(\'/login\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000484e710e00000000022fba2d";}}',
        'as' => 'adminpanel.index',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\AuthController@login',
        'as' => 'adminpanel.login',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.submitlogin' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adminpanel/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\AuthController@submitlogin',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\AuthController@submitlogin',
        'as' => 'adminpanel.submitlogin',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\AuthController@logout',
        'as' => 'adminpanel.logout',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\DashboardController@index',
        'as' => 'adminpanel.dashboard',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.user.manage' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/manageuser',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\UserController@manage',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\UserController@manage',
        'as' => 'adminpanel.user.manage',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.user.add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/adduser',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\UserController@add',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\UserController@add',
        'as' => 'adminpanel.user.add',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.user.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adminpanel/adduser',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\UserController@save',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\UserController@save',
        'as' => 'adminpanel.user.save',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.user.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/edituser/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\UserController@edit',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\UserController@edit',
        'as' => 'adminpanel.user.edit',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.user.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adminpanel/edituser',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\UserController@update',
        'as' => 'adminpanel.user.update',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.user.delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/deleteuser/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\UserController@delete',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\UserController@delete',
        'as' => 'adminpanel.user.delete',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.user.search' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/searchuser',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\UserController@search',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\UserController@search',
        'as' => 'adminpanel.user.search',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.manager.manage' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/managemanager',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\ManagerController@manage',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\ManagerController@manage',
        'as' => 'adminpanel.manager.manage',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.manager.add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/addmanager',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\ManagerController@add',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\ManagerController@add',
        'as' => 'adminpanel.manager.add',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.manager.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adminpanel/addmanager',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\ManagerController@save',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\ManagerController@save',
        'as' => 'adminpanel.manager.save',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.manager.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/editmanager/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\ManagerController@edit',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\ManagerController@edit',
        'as' => 'adminpanel.manager.edit',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.manager.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adminpanel/editmanager',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\ManagerController@update',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\ManagerController@update',
        'as' => 'adminpanel.manager.update',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.manager.delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/deletemanager/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\ManagerController@delete',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\ManagerController@delete',
        'as' => 'adminpanel.manager.delete',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.manager.search' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/searchmanager',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\ManagerController@search',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\ManagerController@search',
        'as' => 'adminpanel.manager.search',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.category.manage' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/managecategory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\CategoryController@manage',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\CategoryController@manage',
        'as' => 'adminpanel.category.manage',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.category.add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/addcategory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\CategoryController@add',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\CategoryController@add',
        'as' => 'adminpanel.category.add',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.category.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adminpanel/addcategory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\CategoryController@save',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\CategoryController@save',
        'as' => 'adminpanel.category.save',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.category.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/editcategory/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\CategoryController@edit',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\CategoryController@edit',
        'as' => 'adminpanel.category.edit',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.category.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adminpanel/editcategory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\CategoryController@update',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\CategoryController@update',
        'as' => 'adminpanel.category.update',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.category.delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/deletecategory/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\CategoryController@delete',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\CategoryController@delete',
        'as' => 'adminpanel.category.delete',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.category.search' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/searchcategory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\CategoryController@search',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\CategoryController@search',
        'as' => 'adminpanel.category.search',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.job.manage' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/managejob',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\JobController@manage',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\JobController@manage',
        'as' => 'adminpanel.job.manage',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.job.add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/addjob',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\JobController@add',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\JobController@add',
        'as' => 'adminpanel.job.add',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.job.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adminpanel/addjob',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\JobController@save',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\JobController@save',
        'as' => 'adminpanel.job.save',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.job.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/editjob/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\JobController@edit',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\JobController@edit',
        'as' => 'adminpanel.job.edit',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.job.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adminpanel/editjob',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\JobController@update',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\JobController@update',
        'as' => 'adminpanel.job.update',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.job.delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/deletejob/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\JobController@delete',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\JobController@delete',
        'as' => 'adminpanel.job.delete',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.job.search' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/searchjob',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\JobController@search',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\JobController@search',
        'as' => 'adminpanel.job.search',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.job.ajaxgetuser' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/ajaxgetuser/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\JobController@ajaxgetuser',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\JobController@ajaxgetuser',
        'as' => 'adminpanel.job.ajaxgetuser',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'adminpanel.job.view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminpanel/viewjob/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\adminpanel\\JobController@view',
        'controller' => 'App\\Http\\Controllers\\adminpanel\\JobController@view',
        'as' => 'adminpanel.job.view',
        'namespace' => 'App\\Http\\Controllers\\adminpanel',
        'prefix' => 'adminpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":261:{@JZyrJvg+oj+jM0aaQhn2YvtTbimohPJr+y0nLCEdrLY=.a:5:{s:3:"use";a:0:{}s:8:"function";s:49:"function () {
    return \\redirect(\'/login\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000484e716b00000000022fba2d";}}',
        'as' => 'managerpanel.index',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\AuthController@login',
        'as' => 'managerpanel.login',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.submitlogin' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'managerpanel/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\AuthController@submitlogin',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\AuthController@submitlogin',
        'as' => 'managerpanel.submitlogin',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\AuthController@logout',
        'as' => 'managerpanel.logout',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\DashboardController@index',
        'as' => 'managerpanel.dashboard',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.user.manage' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/manageuser',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\UserController@manage',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\UserController@manage',
        'as' => 'managerpanel.user.manage',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.user.add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/adduser',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\UserController@add',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\UserController@add',
        'as' => 'managerpanel.user.add',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.user.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'managerpanel/adduser',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\UserController@save',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\UserController@save',
        'as' => 'managerpanel.user.save',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.user.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/edituser/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\UserController@edit',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\UserController@edit',
        'as' => 'managerpanel.user.edit',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.user.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'managerpanel/edituser',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\UserController@update',
        'as' => 'managerpanel.user.update',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.user.delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/deleteuser/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\UserController@delete',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\UserController@delete',
        'as' => 'managerpanel.user.delete',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.user.search' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/searchuser',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\UserController@search',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\UserController@search',
        'as' => 'managerpanel.user.search',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.manager.manage' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/managemanager',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\ManagerController@manage',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\ManagerController@manage',
        'as' => 'managerpanel.manager.manage',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.manager.add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/addmanager',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\ManagerController@add',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\ManagerController@add',
        'as' => 'managerpanel.manager.add',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.manager.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'managerpanel/addmanager',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\ManagerController@save',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\ManagerController@save',
        'as' => 'managerpanel.manager.save',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.manager.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/editmanager/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\ManagerController@edit',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\ManagerController@edit',
        'as' => 'managerpanel.manager.edit',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.manager.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'managerpanel/editmanager',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\ManagerController@update',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\ManagerController@update',
        'as' => 'managerpanel.manager.update',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.manager.delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/deletemanager/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\ManagerController@delete',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\ManagerController@delete',
        'as' => 'managerpanel.manager.delete',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.manager.search' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/searchmanager',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\ManagerController@search',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\ManagerController@search',
        'as' => 'managerpanel.manager.search',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.category.manage' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/managecategory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\CategoryController@manage',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\CategoryController@manage',
        'as' => 'managerpanel.category.manage',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.category.add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/addcategory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\CategoryController@add',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\CategoryController@add',
        'as' => 'managerpanel.category.add',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.category.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'managerpanel/addcategory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\CategoryController@save',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\CategoryController@save',
        'as' => 'managerpanel.category.save',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.category.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/editcategory/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\CategoryController@edit',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\CategoryController@edit',
        'as' => 'managerpanel.category.edit',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.category.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'managerpanel/editcategory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\CategoryController@update',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\CategoryController@update',
        'as' => 'managerpanel.category.update',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.category.delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/deletecategory/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\CategoryController@delete',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\CategoryController@delete',
        'as' => 'managerpanel.category.delete',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.category.search' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/searchcategory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\CategoryController@search',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\CategoryController@search',
        'as' => 'managerpanel.category.search',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.job.manage' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/managejob',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\JobController@manage',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\JobController@manage',
        'as' => 'managerpanel.job.manage',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.job.add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/addjob',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\JobController@add',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\JobController@add',
        'as' => 'managerpanel.job.add',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.job.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'managerpanel/addjob',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\JobController@save',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\JobController@save',
        'as' => 'managerpanel.job.save',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.job.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/editjob/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\JobController@edit',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\JobController@edit',
        'as' => 'managerpanel.job.edit',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.job.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'managerpanel/editjob',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\JobController@update',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\JobController@update',
        'as' => 'managerpanel.job.update',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.job.delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/deletejob/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\JobController@delete',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\JobController@delete',
        'as' => 'managerpanel.job.delete',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.job.search' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/searchjob',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\JobController@search',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\JobController@search',
        'as' => 'managerpanel.job.search',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.job.ajaxgetuser' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/ajaxgetuser/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\JobController@ajaxgetuser',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\JobController@ajaxgetuser',
        'as' => 'managerpanel.job.ajaxgetuser',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'managerpanel.job.view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'managerpanel/viewjob/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:manager',
        ),
        'uses' => 'App\\Http\\Controllers\\managerpanel\\JobController@view',
        'controller' => 'App\\Http\\Controllers\\managerpanel\\JobController@view',
        'as' => 'managerpanel.job.view',
        'namespace' => 'App\\Http\\Controllers\\managerpanel',
        'prefix' => 'managerpanel',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);
