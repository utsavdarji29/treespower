<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Manager Task</title>
        <link rel="stylesheet" href="{{ asset('managerpanel/css/bootstrap.min.css') }}">
        <link rel="stylesheet" href="{{ asset('managerpanel/css/fontawesome-all.css') }}" >
        <link rel="stylesheet" href="{{ asset('managerpanel/css/searchboxstyle.css') }}">
        <link rel="stylesheet" href="{{ asset('managerpanel/css/slick.css') }}">
        <link rel="stylesheet" href="{{ asset('managerpanel/css/slick-theme.css') }}">
        <link rel="stylesheet" href="{{ asset('managerpanel/css/style.css') }}" >
        <link rel="stylesheet" href="{{ asset('managerpanel/css/responsive.css') }}" >
        <style type="text/css">
        .info {
                color: darkblue;
                font-size: 18px;
                border: none;
                text-decoration: none;
          }
        </style>
    </head>
    <body>
        <div class="main" id="main-site">
            <div class="admin-dashboard manager-task-dash">
                <div class="container">
                    <div class="admin-dashboard-main">
                        <div class="admin-dashboard-leftsidebar">
                            <div class="admin-dashboard-leftsidebar-bg-part">
                                <div class="admin-dashboard-logo">
                                    <a href="{{ route('adminpanel.dashboard') }}">
                                    <img src="{{ asset('managerpanel/images/Logo_img.png') }}">
                                    </a>
                                </div>
                                 <div class="admin-dashboard-menu-part">
                                     <ul>
                                        <li>
                                            <a href="{{ route('adminpanel.dashboard') }}">
                                                <img src="{{ asset('managerpanel/images/dashboard-icn.png') }}">
                                            <span>DASHBOARD</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="{{ route('adminpanel.user.manage') }}">
                                                <img src="{{ asset('managerpanel/images/Users-icn.png') }}">
                                            <span>Manage Users</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="{{ route('adminpanel.manager.manage') }}">
                                                <img src="{{ asset('managerpanel/images/Users-icn.png') }}">
                                            <span>Manage Manager</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="{{ route('adminpanel.category.manage') }}">
                                                <img src="{{ asset('managerpanel/images/Users-icn.png') }}">
                                            <span>Manage Category</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="{{ route('adminpanel.job.manage') }}" class="active">
                                                <img src="{{ asset('managerpanel/images/Users-icn.png') }}">
                                            <span>Manage Task</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="admin-dashboard-messages-icn">
                                   <ul>
                                        <li>
                                            <a href="{{ route('adminpanel.logout') }}">
                                                <img src="{{ asset('managerpanel/images/Users-icn.png') }}">
                                            <span>Logout</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="admin-dashboard-right Manager-task-right-main">
                            <div class="admin-dashboard-searchbar-part">
                                <div class="admin-dashboard-searchbar">
                                    <!-- <span class="search-icn"><img src="{{ asset('managerpanel/images/search.png') }}"></span>
                                    <form method="get" action="{{ route('adminpanel.job.search') }}" enctype="multipart/form-data" style="display: flex;" id="search_form">
                                        <input class="search-sm" type="text" name="search" placeholder="Search..." aria-label="Search">
                                        <div class="input-group-append">
                                            <!-- <span class="input-group-text lighten-3" id="basic-text1"><i class="fas fa-search text-grey"
                                                aria-hidden="true"></i></span>
                                        </div>
                                    </form> -->
                                   <!--  <input type="text" name="Search" placeholder="Search" class="search-sm"> -->
                                </div>
                                <div class="admin-dashboard-right-dtl">
                                    @include('adminpanel.include.Searchbar')
                                </div>
                            </div>
                            <div class="admin-dashboard-user-dtl Manager-task-user-dtl">
                                <div class="admin-dashboard-user-left-dtl">
                                    <div class="admin-dashboard-user-name">
                                        <h2>TASKS:(<span>{{ $task }}</span>)</h2>
                                    </div>
                                    <div class="admin-dashboard-user-sm-list">
                                        <ul>
                                            <li>To Do <strong>{{ $todo }}</strong></li>
                                            <li>In progress:<strong>{{ $inprogress }}</strong></li>
                                            <li>Done:<strong>{{ $done }}</strong></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="admin-dashboard-user-right-dtl">
                                    <div class="admin-dashboard-sing-plus-icon">
                                        <a href="{{ route('adminpanel.job.add') }}"><img src="{{ asset('managerpanel/images/plus.png') }}"></a>
                                    </div>
                                </div>
                            </div>
                            @if(session()->has('success'))
                                <div class="alert alert-info">
                                    {{ session('success') }}
                                </div>
                            @endif
                            @if($errors->any())
                                <div class="alert alert-danger">                    
                                    <p>{{$errors->first()}}</p>
                                </div>
                            @endif
                            <div class="admin-list-part manager-task-list-part-main">
                                <div class="admin-dashboard-list-box">
                                    <div class="manager-task-list-name">
                                        <div class="manager-task-list-name-left">
                                            <h4>New Tasks:</h4>
                                        </div>
                                    </div>
                                    <table>
                                        <thead>
                                            <tr>
                                                <th style="text-align: right;width: 3%;">ID
                                                   <!--  <div class="users-name">
                                                        <select class="users-name-select">
                                                            <option value="0">Name</option>
                                                            <option value="0">Name2</option>
                                                        </select>
                                                        <input type="text" name="Start typing" placeholder="Start typing" class="user-name-search">
                                                    </div> -->
                                                </th>
                                                <th style="text-align: right;width: 20%;">Job Title
                                                    <!-- <div class="users-name" style="text-align: right;">
                                                        <select class="users-name-select">
                                                            <option value="0">Edited</option>
                                                            <option value="0">Edited2</option>
                                                        </select>
                                                    </div> -->
                                                </th>
                                                <th style="text-align: right;width: 20%;">Category
                                                    <!-- <div class="users-name" style="text-align: right;padding-left: 12px;">
                                                        <select class="users-name-select">
                                                            <option value="0">Role</option>
                                                            <option value="0">Role2</option>
                                                        </select>
                                                    </div> -->
                                                </th>
                                                <th style="text-align: right;width: 24%">Description
                                                    <!-- <div class="edit-select">
                                                        <select class="users-name-select">
                                                            <option value="0">Edit selected</option>
                                                            <option value="0">Edit selected2</option>
                                                        </select>
                                                    </div> -->
                                                </th>
                                                <th style="text-align: right;width: 24%">Action
                                                    <!-- <div class="edit-select">
                                                        <select class="users-name-select">
                                                            <option value="0">Edit selected</option>
                                                            <option value="0">Edit selected2</option>
                                                        </select>
                                                    </div> -->
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $counter = 0; ?>
                                            @foreach ($Todo as $t)
                                            <?php $counter++; ?>
                                            <tr>
                                                <td style="text-align: right;width: 3%;">{{ $counter }}</td>
                                               <!--  <td>
                                                   <div class="user-pic-dtl">
                                                       <label class="user-check">
                                                          <input type="checkbox">
                                                          <span class="checkmark"></span>
                                                        </label>
                                                   </div> 
                                                </td> -->
                                                <td style="text-align: right;width: 16%;">{{ $t->job_title }} </td>
                                                <td style="text-align: right;width: 20%;">{{ $t->category_title_name}} </td>
                                                <td style="text-align: right;width: 24%;">
                                                    
                                                    {{ strlen($t->description) > 10 ? substr($t->description,0,10).'..' : $t->description }}
                                                </td>
                                                <td style="text-align: right;width: 24%">
                                                    <div class="users-edit dropdown-menu-list">
                                                        <a href="javascript:;" data-toggle="dropdown">
                                                            <img src="http://keshavinfotechdemo1.com/keshav/KG1/Chun/public/managerpanel/images/th-icon.png"></a>
                                                            <div class="dropdown-menu">
                                                                <a class="dropdown-item" href="{{ url('/adminpanel/viewjob/'.$t->id) }}"><span><i class="fas fa-eye"></i></span>View</a>
                                                                <a class="dropdown-item" href="{{ url('/adminpanel/editjob/'.$t->id) }}"><span><i class="fas fa-edit"></i></span>Edit</a>
                                                                <a class="dropdown-item" href="{{ url('/adminpanel/deletejob/'.$t->id) }}"><span><i class="fas fa-trash-alt"></i></span>Delete</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                    <div class="admin-dashboard-bottom-dtl">
                                        <div class="admin-dashboard-bottom-left">
                                            <nav aria-label="Page navigation example">
                                                <ul class="pagination">
                                                    {{ $data->render() }}
                                                </ul>
                                            </nav>
                                        </div>
                                        <!-- <div class="admin-dashboard-bottom-left admin-dashboard-bottom-right">
                                            <div class="admin-dashboard-bottom-select">
                                                <select class="ad-dsh-select">
                                                    <option value="">Edit selected</option>
                                                    <option value="">Edit selected1</option>
                                                </select>
                                                <div class="admin-edit-delete">
                                                    <a href="javascript:;">Delete</a>
                                                </div>
                                            </div>
                                        </div> -->
                                    </div>
                                </div>
                                <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
                                <div class="admin-dashboard-list-box">
                                    <div class="manager-task-list-name">
                                        <div class="manager-task-list-name-left">
                                            <h4>In Progress:</h4>
                                        </div>
                                       <!--  <div class="manager-task-list-name-left">
                                            <div class="edit-select">
                                                <div class="add-users-role country add-us-inp">
                                                    <div id="country1" class="select">
                                                        <span>Edit selected</span>
                                                    </div>
                                                    <div id="country-drop" class="dropdown">
                                                        <ul>
                                                            <li>Move to new</li>
                                                            <li>Move to done</li>
                                                            <li>Delete</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> -->
                                    </div>
                                    <table>
                                        <thead>
                                            <tr>
                                                <th style="text-align: right;width: 3%;">ID
                                                   <!--  <div class="users-name">
                                                        <select class="users-name-select">
                                                            <option value="0">Name</option>
                                                            <option value="0">Name2</option>
                                                        </select>
                                                        <input type="text" name="Start typing" placeholder="Start typing" class="user-name-search">
                                                    </div> -->
                                                </th>
                                                <th style="text-align: right;width: 20%;">Job Title
                                                    <!-- <div class="users-name" style="text-align: right;">
                                                        <select class="users-name-select">
                                                            <option value="0">Edited</option>
                                                            <option value="0">Edited2</option>
                                                        </select>
                                                    </div> -->
                                                </th>
                                                <th style="text-align: right;width: 20%;">Category
                                                    <!-- <div class="users-name" style="text-align: right;padding-left: 12px;">
                                                        <select class="users-name-select">
                                                            <option value="0">Role</option>
                                                            <option value="0">Role2</option>
                                                        </select>
                                                    </div> -->
                                                </th>
                                                <th style="text-align: right;width: 24%">Description
                                                    <!-- <div class="edit-select">
                                                        <select class="users-name-select">
                                                            <option value="0">Edit selected</option>
                                                            <option value="0">Edit selected2</option>
                                                        </select>
                                                    </div> -->
                                                </th>
                                                <th style="text-align: right;width: 24%">Action
                                                    <!-- <div class="edit-select">
                                                        <select class="users-name-select">
                                                            <option value="0">Edit selected</option>
                                                            <option value="0">Edit selected2</option>
                                                        </select>
                                                    </div> -->
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $counter = 0; ?>
                                            @foreach ($Inprogress as $i)
                                            <?php $counter++; ?>
                                            <tr>
                                                <td style="text-align: right;width: 3%;">{{ $counter }}</td>
                                                <!-- <td>
                                                   <div class="user-pic-dtl">
                                                       <label class="user-check">
                                                          <input type="checkbox">
                                                          <span class="checkmark"></span>
                                                        </label>
                                                   </div> 
                                                </td> -->
                                                <td style="text-align: right;width: 16%;">{{ $i->job_title }} </td>
                                                <td style="text-align: right;width: 20%;">{{ $i->category_title_name}} </td>
                                                <td style="text-align: right;width: 24%;">
                                                    
                                                    {{ strlen($i->description) > 10 ? substr($i->description,0,10).'..' : $i->description }}
                                                </td>
                                                <td style="text-align: right;width: 24%">
                                                    <div class="users-edit dropdown-menu-list">
                                                        <a href="javascript:;" data-toggle="dropdown">
                                                            <img src="http://keshavinfotechdemo1.com/keshav/KG1/Chun/public/managerpanel/images/th-icon.png"></a>
                                                            <div class="dropdown-menu">
                                                                <a class="dropdown-item" href="{{ url('/adminpanel/viewjob/'.$i->id) }}"><span><i class="fas fa-eye"></i></span>View</a>
                                                                <a class="dropdown-item" href="{{ url('/adminpanel/editjob/'.$i->id) }}"><span><i class="fas fa-edit"></i></span>Edit</a>
                                                                <a class="dropdown-item" href="{{ url('/adminpanel/deletejob/'.$i->id) }}"><span><i class="fas fa-trash-alt"></i></span>Delete</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                    <div class="admin-dashboard-bottom-dtl">
                                        <div class="admin-dashboard-bottom-left">
                                            <nav aria-label="Page navigation example">
                                                <ul class="pagination">
                                                    {{ $data->render() }}
                                                </ul>
                                            </nav>
                                        </div>
                                        <!-- <div class="admin-dashboard-bottom-left admin-dashboard-bottom-right">
                                            <div class="admin-dashboard-bottom-select">
                                                <select class="ad-dsh-select">
                                                    <option value="">Edit selected</option>
                                                    <option value="">Edit selected1</option>
                                                </select>
                                                <div class="admin-edit-delete">
                                                    <a href="javascript:;">Delete</a>
                                                </div>
                                            </div>
                                        </div> -->
                                    </div>
                                </div>
                                <div class="admin-dashboard-list-box">
                                    <div class="manager-task-list-name">
                                        <div class="manager-task-list-name-left">
                                            <h4>DONE:</h4>
                                        </div>
                                        <!-- <div class="manager-task-list-name-left">
                                            <div class="edit-select">
                                                <div class="add-users-role country add-us-inp">
                                                    <div id="country2" class="select">
                                                        <span>Edit selected</span>
                                                    </div>
                                                    <div id="country-drop" class="dropdown">
                                                        <ul>
                                                            <li>Move to new</li>
                                                            <li>Move to done</li>
                                                            <li>Delete</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> -->
                                    </div>
                                    <table>
                                        <thead>
                                            <tr>
                                                <th style="text-align: right;width: 3%;">ID
                                                   <!--  <div class="users-name">
                                                        <select class="users-name-select">
                                                            <option value="0">Name</option>
                                                            <option value="0">Name2</option>
                                                        </select>
                                                        <input type="text" name="Start typing" placeholder="Start typing" class="user-name-search">
                                                    </div> -->
                                                </th>
                                                <th style="text-align: right;width: 20%;">Job Title
                                                    <!-- <div class="users-name" style="text-align: right;">
                                                        <select class="users-name-select">
                                                            <option value="0">Edited</option>
                                                            <option value="0">Edited2</option>
                                                        </select>
                                                    </div> -->
                                                </th>
                                                <th style="text-align: right;width: 20%;">Category
                                                    <!-- <div class="users-name" style="text-align: right;padding-left: 12px;">
                                                        <select class="users-name-select">
                                                            <option value="0">Role</option>
                                                            <option value="0">Role2</option>
                                                        </select>
                                                    </div> -->
                                                </th>
                                                <th style="text-align: right;width: 24%">Description
                                                    <!-- <div class="edit-select">
                                                        <select class="users-name-select">
                                                            <option value="0">Edit selected</option>
                                                            <option value="0">Edit selected2</option>
                                                        </select>
                                                    </div> -->
                                                </th>
                                                <th style="text-align: right;width: 24%">Action
                                                    <!-- <div class="edit-select">
                                                        <select class="users-name-select">
                                                            <option value="0">Edit selected</option>
                                                            <option value="0">Edit selected2</option>
                                                        </select>
                                                    </div> -->
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $counter = 0; ?>
                                            @foreach ($Done as $do)
                                            <?php $counter++; ?>
                                            <tr>
                                                <td style="text-align: right;width: 3%;">{{ $counter }}</td>
                                                <!-- <td>
                                                   <div class="user-pic-dtl">
                                                       <label class="user-check">
                                                          <input type="checkbox">
                                                          <span class="checkmark"></span>
                                                        </label>
                                                   </div> 
                                                </td> -->
                                                <td style="text-align: right;width: 16%;">{{ $do->job_title }} </td>
                                                <td style="text-align: right;width: 20%;">{{ $do->category_title_name}} </td>
                                                <td style="text-align: right;width: 24%;">
                                                    
                                                    {{ strlen($do->description) > 10 ? substr($do->description,0,10).'..' : $do->description }}
                                                </td>
                                                <td style="text-align: right;width: 24%">
                                                    <div class="users-edit dropdown-menu-list">
                                                        <a href="javascript:;" data-toggle="dropdown">
                                                            <img src="http://keshavinfotechdemo1.com/keshav/KG1/Chun/public/managerpanel/images/th-icon.png"></a>
                                                            <div class="dropdown-menu">
                                                                <a class="dropdown-item" href="{{ url('/adminpanel/viewjob/'.$do->id) }}"><span><i class="fas fa-eye"></i></span>View</a>
                                                                <a class="dropdown-item" href="{{ url('/adminpanel/editjob/'.$do->id) }}"><span><i class="fas fa-edit"></i></span>Edit</a>
                                                                <a class="dropdown-item" href="{{ url('/adminpanel/deletejob/'.$do->id) }}"><span><i class="fas fa-trash-alt"></i></span>Delete</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                    <div class="admin-dashboard-bottom-dtl">
                                        <div class="admin-dashboard-bottom-left">
                                            <nav aria-label="Page navigation example">
                                                <ul class="pagination">
                                                    {{ $data->render() }}
                                                </ul>
                                            </nav>
                                        </div>
                                        <!-- <div class="admin-dashboard-bottom-left admin-dashboard-bottom-right">
                                            <div class="admin-dashboard-bottom-select">
                                                <select class="ad-dsh-select">
                                                    <option value="">Edit selected</option>
                                                    <option value="">Edit selected1</option>
                                                </select>
                                                <div class="admin-edit-delete">
                                                    <a href="javascript:;">Delete</a>
                                                </div>
                                            </div>
                                        </div> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
                $label = "Create";
                $job_title = "";
                $description = "";
                $manager_id = "";
                $user_id = "";
                $job_date = "";
                $category_id = "";
                $start_time = "";
                $end_time = "";
                $tags = "";
                $address = "";
                $latitude = "";
                $longitude = "";
                $id = "";
                $statusCheck = "";
                $isError = false;
                $formRoute = route('adminpanel.job.save');
                if(isset($data['error'])) {
                    $isError = true;
                    if($data['type']=="Edit") {
                        $label = "Edit";
                        $formRoute = route('adminpanel.job.update');
                    }

                } else { 
                    if($data['type'] == "edit") {
                        $label = "Edit";
                        $id = $data['input'][0]->id;
                        $job_title = $data['input'][0]->job_title;
                        $description = $data['input'][0]->description;
                        $manager_id = $data['input'][0]->manager_id;
                        $user_id = $data['input'][0]->user_id;
                        $job_date = $data['input'][0]->job_date;
                        $category_id = $data['input'][0]->category_id;
                        $start_time = $data['input'][0]->start_time;
                        $end_time = $data['input'][0]->end_time;
                        $tags = $data['input'][0]->tags;
                        $address = $data['input'][0]->address;
                        $latitude = $data['input'][0]->latitude;
                        $longitude = $data['input'][0]->longitude;
                        $formRoute = route('adminpanel.job.update');

                    }
                } 
                ?>
         <!-- User Details -->
        <div class="modal hide fade add-user-modal" id="add-users-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="user-details-modal-main add-users-sub-dtl">
                            <div class="user-details-sub-dtl">
                                <div class="user-details-head">
                                    <h2>ADD Task:</h2>
                                    <button type="button" class="close" data-dismiss="modal"><img src="{{ asset('managerpanel/images/close-icn.png') }}"></button>
                                </div>
                                <form action="{{ $formRoute }}" method="POST" id="logForm" enctype="multipart/form-data">
                            @csrf
                            <input type="hidden" name="id" value="{{ $id }}">
                                <div class="user-personla-dtl">
                                    <!-- <div class="user-personla-dtl-left-pic">
                                        <img src="images/dummy-pic.png">
                                    </div> -->
                                    <div class="edit-account-img edit-account-mail-left">
                                        
                                        <div class="camera-icon">
                                            
                                        </div>
                                        <div class="logoContainer edit-account-img" style="display: flex; flex-direction: row; align-items: center; justify-content: center; max-width: 500%; max-height: 500%; ">
                                            
                                        </div>
                                        <div class="fileContainer sprite">
                                            
                                        </div>
                                    </div>
                                    <div class="user-personla-dtl-right-side">
                                        <div class="add-users-form">
                                                <div class="add-users-fr-sec-inp">
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            <div class="palceholder">
                                                                <label for="name">Select Manager</label>
                                                                <span class="star">*</span>
                                                            </div>
                                                            <select name="manager_id" class="add-us-inp" id="manager-dropdown" onchange="getUser(this.value)"> 
                                                                @foreach ($manager as $m) 

                                                                <?php
                                                                $optionSelected = "";
                                                                if($m->id == $manager_id)
                                                                {
                                                                    $optionSelected = "selected";
                                                                }
                                                                ?>
                                                                    <option value="{{ $m->id}}" {{ $optionSelected }}> {{ $m->first_name }}</option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            <div class="palceholder">
                                                                <label for="name">Select User</label>
                                                                <span class="star">*</span>
                                                            </div>
                                                            <select name="user_id" class="add-us-inp" id="user_id"> 
                                                                <option {{ $optionSelected }}>--select user--</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="add-users-fr-sec-inp">
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            <div class="palceholder">
                                                                <label for="title">Job Title</label>
                                                                <span class="star">*</span>
                                                            </div>
                                                            <input type="text" name="job_title" value="{{ $job_title }}" class="add-us-inp" placeholder="Enter Job Title" required="true">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            <div class="palceholder">
                                                                <label for="description">Description</label>
                                                                <span class="star">*</span>
                                                            </div>
                                                            <input type="description" name="description" class="add-us-inp form-control" placeholder="Description*" required="">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="add-users-fr-sec-inp">
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            <div class="palceholder">
                                                                <label for="date">Select Date</label>
                                                                <span class="star">*</span>
                                                            </div>
                                                            <input type="date" name="job_date" value="{{ $job_date }}" placeholder="Select Date*" class="add-us-inp" required="">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp">
                                                            <select class="add-us-inp" name="category_id" id="category_id">
                                                                @foreach ($category as $c) 

                                                                <?php
                                                                $optionSelected = "";
                                                                if($c->id == $category_id)
                                                                {
                                                                    $optionSelected = "selected";
                                                                }
                                                                ?>
                                                                <option value="{{ $c->id}}" {{ $optionSelected }}>{{ $c->category_title }}</option>
                                                                @endforeach
                                                            </select>   
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="add-users-fr-sec-inp">
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            <div class="palceholder">
                                                                <label for="time">Select Start Time</label>
                                                                <span class="star">*</span>
                                                            </div>
                                                            <input type="time" name="start_time" value="{{ $start_time }}" placeholder="Select Start Time*" class="add-us-inp" required="">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            <div class="palceholder">
                                                                <label for="time">Select End Time</label>
                                                                <span class="star">*</span>
                                                            </div>
                                                            <input type="time" name="end_time" value="{{ $end_time }}" placeholder="Select End Time*" class="add-us-inp" required="">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="add-users-fr-sec-inp">
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            <div class="palceholder">
                                                                <label for="tag">Enter Tag</label>
                                                                <span class="star">*</span>
                                                            </div>
                                                            <input type="text" name="tags" value="{{ $tags }}" placeholder="Enter Tag*" class="add-us-inp" required="">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            <div class="palceholder">
                                                                <label for="address">Ender Address</label>
                                                                <span class="star">*</span>
                                                            </div>
                                                            <input type="text" name="address" value="{{ $address }}" placeholder="Enter Address*" class="add-us-inp" required="">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="add-users-fr-sec-inp">
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            <div class="palceholder">
                                                                <label for="tag">Enter Latitude</label>
                                                                <span class="star">*</span>
                                                            </div>
                                                            <input type="text" name="latitude" value="{{ $latitude }}" placeholder="Enter Latitude*" class="add-us-inp" required="">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            <div class="palceholder">
                                                                <label for="address">Ender Longitude</label>
                                                                <span class="star">*</span>
                                                            </div>
                                                            <input type="text" name="longitude" value="{{ $longitude }}" placeholder="Enter Longitude*" class="add-us-inp" required="">
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                            <img src="{{ asset('managerpanel/images/save-user.png') }}">
                                            <button class="btn info" type="submit" value="SAVE TASK">SAVE TASK</button>

                                        </div>
                                       
                                                        </div>
                                </div>
                                 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
         <script src="{{ asset('managerpanel/js/jquery.min.js') }}"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="{{ asset('managerpanel/js/bootstrap.min.js') }}"></script>
        <script src="{{ asset('managerpanel/js/slick.min.js') }}"></script>
        <script>
            
                    var confirmDelete = function(section, url) {
            // if(confirm("Are you sure you want to delete " + section)) {
            //  window.location.href = url;
            // }
            swal({
                title: "Are you sure?",
                text: "You want to delete this " + section,
                icon: "error",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    window.location.href = url;
                }
            });
        };
        </script>
        <script type="text/javascript">
            
            var displaySingleImagePreview = function(input, id) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#'+id).attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
        if($('.file-upload-input')) {
            $('.file-upload-input').css('display', 'none');
        }
    }
};
        </script>
        <script>

function getUser(id)
{
    $.ajax
    ({
        type    : 'GET',
        url     : 'http://keshavinfotechdemo1.com/keshav/KG1/Chun/adminpanel/ajaxgetuser/'+id,
        dataType: 'json',
        success: function(response)
        {
            var len = 0;            
            $('#user_id').empty();
            if(response['data'] != null)
            {
                len = response['data'].length;
            }
            if(len > 0)
            {
                for(var i=0; i<len; i++)
                {
                    var id = response['data'][i].id;
                    var first_name = response['data'][i].first_name;
                    if(i==0)
                    {   
                        $("#user_id").append("<option value=''>Select User</option>");
                    }
                    $("#user_id").append("<option value="+ id +">"+ first_name +"</option>");
                }
            }
            else
            {
                $("#user_id").append("<option value=''>No record found</option>");
            }
        }
    });
}
</script>
        <script type="text/javascript">
        function countryDropdown(seletor){
            var Selected = $(seletor);
            var Drop = $(seletor+'-drop');
            var DropItem = Drop.find('li');

            Selected.click(function(){
                Selected.toggleClass('open');
                Drop.toggle();
            });

            Drop.find('li').click(function(){
                Selected.removeClass('open');
                Drop.hide();
                
                var item = $(this);
                Selected.html(item.html());
            });

            DropItem.each(function(){
                var code = $(this).attr('data-code');

                if(code != undefined){
                    var countryCode = code.toLowerCase();
                    $(this).find('i').addClass('flagstrap-'+countryCode);
                }
            });
        }
        countryDropdown('#country');

        function countryDropdown1(seletor){
            var Selected1 = $(seletor1);
            var Drop = $(seletor1+'-drop');
            var DropItem = Drop.find('li');

            Selected1.click(function(){
                Selected1.toggleClass('open');
                Drop.toggle();
            });

            Drop.find('li').click(function(){
                Selected1.removeClass('open');
                Drop.hide();
                
                var item = $(this);
                Selected1.html(item.html());
            });

            DropItem.each(function(){
                var code = $(this).attr('data-code');

                if(code != undefined){
                    var countryCode = code.toLowerCase();
                    $(this).find('i').addClass('flagstrap-'+countryCode);
                }
            });
        }
        countryDropdown1('#country1');
        function countryDropdown(seletor){
            var Selected = $(seletor);
            var Drop = $(seletor+'-drop');
            var DropItem = Drop.find('li');

            Selected.click(function(){
                Selected.toggleClass('open');
                Drop.toggle();
            });

            Drop.find('li').click(function(){
                Selected.removeClass('open');
                Drop.hide();
                
                var item = $(this);
                Selected.html(item.html());
            });

            DropItem.each(function(){
                var code = $(this).attr('data-code');

                if(code != undefined){
                    var countryCode = code.toLowerCase();
                    $(this).find('i').addClass('flagstrap-'+countryCode);
                }
            });
        }
        countryDropdown('#country2');
    </script>
    </body>
</html>

