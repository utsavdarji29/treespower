<h4>Hi {{ $adminName }} You are Admin</h4>
                                    <div class="admin-notification">
                                    	<!-- <img src="{{ asset('managerpanel/images/bell.png') }}">
                                        <span class="noti-dig">99+</span> -->
                                    </div>
                                   <!--  <div class="admin-login-pr">
                                    	<img src="{{ asset('managerpanel/images/men.png') }}">
                                    </div> -->