<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Welcome Adminpanel</title>
    <link rel="stylesheet" href="{{ asset('managerpanel/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('managerpanel/css/fontawesome-all.css') }}" >
    <link rel="stylesheet" href="{{ asset('managerpanel/css/searchboxstyle.css') }}">
    <link rel="stylesheet" href="{{ asset('managerpanel/css/slick.css') }}">
    <link rel="stylesheet" href="{{ asset('managerpanel/css/slick-theme.css') }}">
    <link rel="stylesheet" href="{{ asset('managerpanel/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('managerpanel/css/responsive.css') }}" >
    <style type="text/css">
        .info {
                color: darkblue;
                font-size: 20px;
                border: none;
                text-decoration: none;
          }
    </style>
</head>
<body>
    <div class="main" id="main-site" style="background-image: url('{{ asset('managerpanel/images/login-bg.png')}}');">
        <div class="login-page-main">
            <div class="login-header">
                <div class="logo">
                    <a href="javascript:;">
                        <img src="{{ asset('managerpanel/images/Logo_img.png') }}">
                    </a>
                </div>
            </div>
            <div class="login-form-part-main">
                <div class="login-form-head">
                    <h2>SIGN IN:</h2>
                </div>
                <?php
                    $formURL = route('adminpanel.submitlogin');
                ?>
                @if($errors->any())
                    <div class="error-message-box">                    
                        <p>{{$errors->first()}}</p>
                    </div>
                @endif
                @if(session()->has('username'))
                    <?php print_r(session()->all()); ?>
                @endif
                <div class="login-form-dtl-main">
                    <form action="{{ $formURL }}" method="POST" id="logForm">
                        <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                        <div class="login-form-inp-box login-form-emal-inp">
                            <input type="text" name="username" value="{{ old('username') }}" class="login-inp" placeholder="Username" required="">
                        </div>
                        <div class="login-form-inp-box">
                            <input type="password" name="password" class="login-inp" placeholder="Password">
                        </div>
                        <div class="login-fo-pwd">
                            <a href="javascript:;">Forgot password?</a>
                        </div>
                        <div class="login-sing-in">
                            <a href="javascript:;"><img src="{{ asset('managerpanel/images/lock.png') }}"><button class="btn info" type="submit" value="SIGN IN">SIGN IN</button></a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="{{ asset('managerpanel/js/jquery.min.js') }}"></script>
    <script src="{{ asset('managerpanel/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('managerpanel/js/slick.min.js') }}"></script>
</body>
</html>