<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Admin Dashboard</title>
        <link rel="stylesheet" href="{{ asset('managerpanel/css/bootstrap.min.css') }}">
        <link rel="stylesheet" href="{{ asset('managerpanel/css/fontawesome-all.css') }}" >
        <link rel="stylesheet" href="{{ asset('managerpanel/css/searchboxstyle.css') }}">
        <link rel="stylesheet" href="{{ asset('managerpanel/css/slick.css') }}">
        <link rel="stylesheet" href="{{ asset('managerpanel/css/slick-theme.css') }}">
        <link rel="stylesheet" href="{{ asset('managerpanel/css/style.css') }}" >
        <link rel="stylesheet" href="{{ asset('managerpanel/css/responsive.css') }}" >
    </head>
    <body>
    	<div class="main" id="main-site" style="background-image: url('{{ asset('managerpanel/images/login-bg.png')}}');">
                <div class="container">
                    <div class="admin-dashboard-main">
                        <div class="admin-dashboard-leftsidebar">
                            <div class="admin-dashboard-leftsidebar-bg-part">
                                <div class="admin-dashboard-logo">
                                    <a href="javascript:;">
                                    	<img src="{{ asset('managerpanel/images/Logo_img.png') }}">
                                    </a>
                                </div>
                                <div class="admin-dashboard-menu-part">
                                    <ul>
                                        <li>
                                            <a href="{{ route('adminpanel.dashboard') }}" class="active">
                                                <img src="{{ asset('managerpanel/images/dashboard-icn.png') }}">
                                            <span>DASHBOARD</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="{{ route('adminpanel.user.manage') }}">
                                                <img src="{{ asset('managerpanel/images/Users-icn.png') }}">
                                            <span>Manage Users</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="{{ route('adminpanel.manager.manage') }}">
                                                <img src="{{ asset('managerpanel/images/Users-icn.png') }}">
                                            <span>Manage Manager</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="{{ route('adminpanel.category.manage') }}">
                                                <img src="{{ asset('managerpanel/images/Users-icn.png') }}">
                                            <span>Manage Category</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="{{ route('adminpanel.job.manage') }}">
                                                <img src="{{ asset('managerpanel/images/Users-icn.png') }}">
                                            <span>Manage Task</span>
                                            </a>
                                        </li>
                                    </ul>
                                    
                                </div>
                                <div class="admin-dashboard-messages-icn">
                                    <ul>
                                        <li>
                                            <a href="{{ route('adminpanel.logout') }}">
                                                <img src="{{ asset('managerpanel/images/Users-icn.png') }}">
                                            <span>Logout</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="admin-dashboard-right">
                            <div class="admin-dashboard-searchbar-part">
                                <div class="admin-dashboard-searchbar">
                                    <!-- <span class="search-icn"><img src="{{ asset('managerpanel/images/search.png') }}"></span>
                                    <input type="text" name="Search" placeholder="Search" class="search-sm"> -->
                                </div> 
                                <div class="admin-dashboard-right-dtl">
                                    @include('adminpanel.include.Searchbar')
                                </div>
                            </div>
                            <div class="admin-dashboard-box-main">
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <div class="admin-dashboard-sing-box">
                                        <div class="admin-dashboard-sing-box-head">
                                            <h2>USERS:</h2>
                                            <h1>{{ $data['Users'] }}</h1>
                                        </div>
                                        <div class="admin-dashboard-sing-box-dtl-main">
                                            <div class="admin-dashboard-sm-dtl">
                                                <h2>Admins:<strong>{{ $data['Admins'] }}</strong></h2>
                                            </div>
                                            <div class="admin-dashboard-sm-dtl">
                                                <h2>Managers:<strong>{{ $data['Managers'] }}</strong></h2>
                                            </div>
                                            <!-- <div class="admin-dashboard-sm-dtl">
                                                <h2>Operators:<strong></strong></h2>
                                            </div> -->
                                        </div>
                                        <div class="admin-dashboard-sing-plus-icon">
                                      
                                            <a href="{{ route('adminpanel.user.manage') }}" ><img src="{{ asset('managerpanel/images/plus.png') }}"></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <div class="admin-dashboard-sing-box">
                                        <div class="admin-dashboard-sing-box-head">
                                            <h2>Tasks:</h2>
                                            <h1>{{ $data['Task'] }}</h1>
                                        </div>
                                        <div class="admin-dashboard-sing-box-dtl-main">
                                            <div class="admin-dashboard-sm-dtl">
                                                <h2>To Do:<strong>{{ $data['To do'] }}</strong></h2>
                                            </div>
                                            <div class="admin-dashboard-sm-dtl">
                                                <h2>In Progress:<strong>{{ $data['In progress'] }}</strong></h2>
                                            </div>
                                            <div class="admin-dashboard-sm-dtl">
                                                <h2>Done<strong>{{ $data['Done'] }}</strong></h2>
                                            </div>
                                        </div>
                                        <div class="admin-dashboard-sing-plus-icon">
                                            <a href="{{ route('adminpanel.job.manage') }}"><img src="{{ asset('managerpanel/images/plus.png') }}"></a>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                            <br/><br/>
                            <div class="admin-dashboard-box-main">
                                <!-- <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <div class="admin-dashboard-sing-box">
                                        <div class="admin-dashboard-sing-box-head">
                                            <h2>REPORTS:</h2>
                                            <h1></h1>
                                        </div>
                                        <div class="admin-dashboard-sing-box-dtl-main">
                                            <div class="admin-dashboard-sm-dtl">
                                                <h2>New reports:<strong></strong></h2>
                                            </div>
                                            <div class="admin-dashboard-sm-dtl">
                                                <h2>Checked:<strong></strong></h2>
                                            </div>
                                        </div>
                                        <div class="admin-dashboard-sing-plus-icon">
                                            <a href="javascript:;"><img src="{{ asset('managerpanel/images/plus.png') }}"></a>
                                        </div>
                                    </div> -->
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <!-- <div class="admin-dashboard-sing-box">
                                        <div class="admin-dashboard-sing-box-head">
                                            <h2>AREAS:</h2>
                                            <h1></h1>
                                        </div>
                                        <div class="admin-dashboard-sing-box-dtl-main">
                                            <div class="admin-dashboard-sm-dtl">
                                                <h2>Parks:<strong></strong></h2>
                                            </div>
                                            <div class="admin-dashboard-sm-dtl">
                                                <h2>Forests:<strong></strong></h2>
                                            </div>
                                        </div>
                                        <div class="admin-dashboard-sing-plus-icon">
                                            <a href="javascript:;"><img src="{{ asset('managerpanel/images/plus.png') }}"></a>
                                        </div>
                                    </div> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="{{ asset('managerpanel/js/jquery.min.js') }}"></script>
        <script src="{{ asset('managerpanel/js/bootstrap.min.js') }}"></script>
        <script src="{{ asset('managerpanel/js/slick.min.js') }}"></script>
    </body>
</html>