<?php

namespace App\Http\Controllers\managerpanel;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Manager;
use App\Models\Job;
use App\Models\User;
use DB;

class DashboardController extends Controller
{
    public function index() {
    	/*$data = array(
    		'User' => User::query()->count(),
    		'To do' => Job::where('status',1)->count(),
    		'In progress' => Job::where('status',2)->count(),
    		'Done' => Job::where('status',3)->count(),
    		'Task' => Job::where('status',1)->count() + Job::where('status',2)->count() + Job::where('status',3)->count(),
    	);*/
        $managerName = "";
        $managerimage = "";
        $loginUserId = AUTH::user()->id;
        $manager = Manager::where('id','=',$loginUserId)->get();
        if (count($manager)>0) 
        {
            $managerName = $manager[0]->first_name." ".$manager[0]->last_name;
            if ($manager[0]->managerImage != "" && $manager[0]->managerImage != null) 
            {
                if(file_exists(public_path()."/uploads/managerImages/".$manager[0]->managerImage))
                {
                    $managerimage = asset('uploads/managerImages/'.$manager[0]->managerImage);
                }
            }
        }
        
        $data = DB::table('users')
            ->select('users.*')
            ->join('managers','users.manager_id','managers.id')
            ->where('manager_id','=',$loginUserId)
            ->count();
        $task = Job::where('manager_id','=',$loginUserId)->count();
        $todo = Job::where('manager_id','=',$loginUserId)->where('status','=',1)->count();
        $inprogress = Job::where('manager_id','=',$loginUserId)->where('status','=',2)->count();
        $done = Job::where('manager_id','=',$loginUserId)->where('status','=',3)->count();
    	return view('managerpanel.dashboard',compact('data','task','todo','inprogress','done','managerName','managerimage'));
    }
}
