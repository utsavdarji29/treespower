<?php

namespace App\Http\Controllers\managerpanel;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth; 
use App\Models\Manager;
use Validator;

class AuthController extends Controller
{
    public function login()
    {
        return view('managerpanel.login');
    }

    public function submitlogin(Request $request) {
    	try
		{
            $validator = Validator::make( $request->all(), $this->getRules('Add', $request->all()), $this->messages());
            if ($validator->fails())
			{
                return redirect()->back()->withInput()->withErrors($validator->messages());
            }
            if (Auth::guard('manager')->attempt(['email' => $request->email, 'password' => $request->password], $request->get('remember')))
			{
				$data = Manager::query()->where('email',$request->email)->first();

				if($data)
				{
	                return redirect()->route('managerpanel.dashboard');
				}
				else
				{
					Auth::logout();
					//return redirect()->route('managerpanel.login');
					return redirect()->back()->withInput()->withErrors(['Invalid Manager']);
				}
            }

            return redirect()->back()->withInput()->withErrors(['Invalid email or password.']);
        } catch (RuntimeException $ex) {
            return redirect()->back()->withInput()->withErrors([$ex->getMessage()]);
        }
    }

    public function logout() {
    	Auth::logout();
    	return redirect()->route('managerpanel.login');
    }

    private function getRules($type, $input) {
        $return = array();
        $return['email'] = 'required|max:50';
        $return['password'] = 'required|max:20';
        return $return;
    }

    private function messages() {
        return [
            // 'question.required'  => 'The question field is required.'
        ];
    }
}
