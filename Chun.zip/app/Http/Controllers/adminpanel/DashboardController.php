<?php

namespace App\Http\Controllers\adminpanel;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Manager;
use App\Models\Admin;
use App\Models\Job;
class DashboardController extends Controller
{
    public function index() {
        $loginUserId = AUTH::user()->id;
        $admin = Admin::where('id','=',$loginUserId)->get();
        if (count($admin)>0) 
        {
            $adminName = $admin[0]->username;
           
        }
    	$data = array(
            'Admin' => Admin::where('id','=',$loginUserId)->get(),
    		'Admins' => Admin::count(),
    		'Users' => User::count(),
    		'Managers' => Manager::count(),
    		'To do' => Job::where('status',1)->count(),
    		'In progress' => Job::where('status',2)->count(),
    		'Done' => Job::where('status',3)->count(),
    		'Task' => Job::where('status',1)->count() + Job::where('status',2)->count() + Job::where('status',3)->count(),
    	);
    	return view('adminpanel.dashboard', compact('data','adminName'));
    }
}