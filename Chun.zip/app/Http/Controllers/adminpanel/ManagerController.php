<?php

namespace App\Http\Controllers\adminpanel;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Manager;
use App\Models\Admin;
use App\Models\Job;
use Validator;
use Illuminate\Pagination\Paginator;

class ManagerController extends Controller
{
     private $pagination = 10;

    public function manage() {
         $data = Manager::query()->paginate($this->pagination);
         $loginUserId = AUTH::user()->id;
            $admin = Admin::where('id','=',$loginUserId)->get();
            if (count($admin)>0) 
            {
                $adminName = $admin[0]->username;
               
            }
            $data1 = array(
            'Admins' => Admin::count(),
            'Users' => User::count(),
            'Managers' => Manager::count(),
            'To do' => Job::where('status',1)->count(),
            'In progress' => Job::where('status',2)->count(),
            'Done' => Job::where('status',3)->count(),
            'Task' => Job::where('status',1)->count() + Job::where('status',2)->count() + Job::where('status',3)->count(),
        );
        return view('adminpanel.managemanager', compact('data','data1','adminName'));
    }

    public function search(Request $request) 
    {
        $loginUserId = AUTH::user()->id;
            $admin = Admin::where('id','=',$loginUserId)->get();
            if (count($admin)>0) 
            {
                $adminName = $admin[0]->username;
               
            }
            $data1 = array(
            'Admins' => Admin::count(),
            'Users' => User::count(),
            'Managers' => Manager::count(),
            'To do' => Job::where('status',1)->count(),
            'In progress' => Job::where('status',2)->count(),
            'Done' => Job::where('status',3)->count(),
            'Task' => Job::where('status',1)->count() + Job::where('status',2)->count() + Job::where('status',3)->count(),
        );
        $input = $request->all();
        $qry = Manager::query(); 
        if(trim($input["search"])!="") {
            $search = $input["search"];
            $qry->where([
                ["first_name", "like", "%{$search}%"],
            ]);
            $qry->orwhere([
                ["email", "like", "%{$search}%"],
            ]);
        }
        $data = $qry->paginate($this->pagination);
        $data->appends($input);
        return view('adminpanel.managemanager', compact('data','data1','adminName'));
    }

    public function add() 
    {    
        $loginUserId = AUTH::user()->id;
            $admin = Admin::where('id','=',$loginUserId)->get();
            if (count($admin)>0) 
            {
                $adminName = $admin[0]->username;
               
            }
            $data1 = array(
                'Admin' => Admin::where('id','=',$loginUserId)->get(),
                'Admins' => Admin::count(),
                'Users' => User::count(),
                'Managers' => Manager::count(),
                'To do' => Job::where('status',1)->count(),
                'In progress' => Job::where('status',2)->count(),
                'Done' => Job::where('status',3)->count(),
                'Task' => Job::where('status',1)->count() + Job::where('status',2)->count() + Job::where('status',3)->count(),
            );
        $data = array('type'=>'add','adminName' => $adminName,'data1'=>$data1);
        return view('adminpanel.addmanager', compact('data','adminName','data1'));
    }

    public function save(Request $request) {
        $input = $request->all();

        $loginUserId = AUTH::user()->id;
            $admin = Admin::where('id','=',$loginUserId)->get();
            if (count($admin)>0) 
            {
                $adminName = $admin[0]->username;
               
            }
            $data1 = array(
            'Admin' => Admin::where('id','=',$loginUserId)->get(),
            'Admins' => Admin::count(),
            'Users' => User::count(),
            'Managers' => Manager::count(),
            'To do' => Job::where('status',1)->count(),
            'In progress' => Job::where('status',2)->count(),
            'Done' => Job::where('status',3)->count(),
            'Task' => Job::where('status',1)->count() + Job::where('status',2)->count() + Job::where('status',3)->count(),
        );
            
        $validator=Validator::make($input,$this->getRules('Add',$input),$this->messages());

        if($validator->fails())
        {
            $data = array('type'=>'add','input'=>$input,'adminName' => $adminName,'data1'=>$data1,'error'=>$validator->messages());
            return view('adminpanel.addmanager', compact('data','adminName','data1'));
            exit();
        }

        $filename = "";
        if(isset($input["managerImage"])) {
            $imagePath = request('managerImage');// $input["userImage"];
            $filename = rand(0000,9999).$imagePath->getClientOriginalName();
            $extension  = pathinfo($imagePath->getClientOriginalName(), PATHINFO_EXTENSION);
            $filename = rand(0000,9999)."userpic.".$extension;
            $upload_dir_path = public_path()."/uploads/managerImages";
            $imagePath->move($upload_dir_path, $filename );            
        }
        $input['managerImage'] = $filename;
        $input['password'] = bcrypt($input['password']);
        
        $manager = Manager::create($input);
        if($manager->id>0) {
            return redirect()->route('adminpanel.manager.manage')->with('success', 'Created successfully.');
        } else {
            return redirect()->route('adminpanel.manager.add')->withErrors(['Error creating record. Please try again.']);
        }
    }

    public function edit($id) {
        $loginUserId = AUTH::user()->id;
            $admin = Admin::where('id','=',$loginUserId)->get();
            if (count($admin)>0) 
            {
                $adminName = $admin[0]->username;
               
            }
            $data1 = array(
            'Admins' => Admin::count(),
            'Users' => User::count(),
            'Managers' => Manager::count(),
            'To do' => Job::where('status',1)->count(),
            'In progress' => Job::where('status',2)->count(),
            'Done' => Job::where('status',3)->count(),
            'Task' => Job::where('status',1)->count() + Job::where('status',2)->count() + Job::where('status',3)->count(),
        );
        $how_hear_abouts = array();//How_hear_about::where("is_active", "=", "1")->pluck('name', 'id');
        $input = Manager::where('id', '=', $id)->get();
        $data = array('type'=>'edit', 'input'=>$input, 'how_hear_abouts'=>$how_hear_abouts);
        return view('adminpanel.addmanager', compact('data','adminName','data1','input'));
    }

    public function update(Request $request) {
        $input = $request->all();
        $id = $input['id'];
        //echo "<br>";
        /*$validator = Validator::make( $input, $this->getRules('Edit', $input), $this->messages()); 
        
        if ($validator->fails()) { 
            $how_hear_abouts = array();//How_hear_about::where("is_active", "=", "1")->pluck('name', 'id');
            $data = array('type'=>'Edit', 'input'=>$input, 'how_hear_abouts'=>$how_hear_abouts, 'error'=>$validator->messages());
            return view('adminpanel.adduser', compact('data'));
            exit();            
        }*/
        $update = array();

        if(isset($input["managerImage"])) {
            $imagePath = request('managerImage');// $input["userImage"];
            $filename = rand(0000,9999).$imagePath->getClientOriginalName();
            $extension  = pathinfo($imagePath->getClientOriginalName(), PATHINFO_EXTENSION);
            $filename = rand(0000,9999)."userpic.".$extension;
            $upload_dir_path = public_path()."/uploads/managerImages";
            $imagePath->move($upload_dir_path, $filename ); 
            $update['managerImage'] = $filename;
        }

        $update["first_name"] = $input['first_name'];
        $update["last_name"] = $input['last_name'];
        $update["email"] = $input['email'];
        $update["phone"] = $input['phone'];

        $manager = Manager::where('id', '=', $id)->update($update);

        return redirect()->route('adminpanel.manager.manage')->with('success', 'Updated successfully.');

    }

    public function delete($id) {
        Manager::where('id','=',$id)->delete();
        return redirect()->route('adminpanel.manager.manage')->with('success', 'Deleted successfully.');
    }

    private function getRules($type, $input) {
        $return = array();
        $return['first_name'] = 'required|max:30';
        $return['last_name'] = 'required|max:30';
        if($type=="Edit") {
            $return['email'] = 'required|email|max:100';
        } else {
            $return['email'] = 'required|email|unique:users,email|max:100';
            $return['password'] = 'required|min:6|max:20';
        }
        return $return;
    }

    private function messages() {
        return [
            'first_name.required'  => $this->getRequiredMessage('first_name'),
            'first_name.max'  => $this->getGreaterMessage('first_name', 30),
            'last_name.required'  => $this->getRequiredMessage('last_name'),
            'last_name.max'  => $this->getGreaterMessage('last_name', 30),
        ];
    }

    private function getRequiredMessage($string) {
        return 'The ' . $string . ' field is required.';
    }

    private function getGreaterMessage($string, $maxchar) {
        return 'The ' . $string . ' may not be greater than ' . $maxchar . ' characters.';
    }
}

?>