<?php
namespace App\Http\Controllers\adminpanel;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Job;
use App\Models\Category;
use App\Models\User;
use App\Models\Manager;
use App\Models\Jobimage;
use App\Models\Admin;
use Validator;
use Illuminate\Pagination\Paginator;
use DB;

class JobController extends Controller 
{
    private $pagination = 10;

    public function manage() 
    {
        $loginUserId = AUTH::user()->id;
            $admin = Admin::where('id','=',$loginUserId)->get();
            if (count($admin)>0) 
            {
                $adminName = $admin[0]->username;
               
            }
        $task = Job::query()->count();
        $todo = Job::where('status',1)->count();
        $inprogress = Job::where('status',2)->count();
        $done = Job::where('status',3)->count();
        $data = Job::query()->paginate($this->pagination);
        foreach ($data as $d) 
        {
            $category_title_name = "";
            $category_id=explode(',', $d->category_id);
            for($g=0; $g<count($category_id); $g++)
            {
                $category_title = Category::where('id', '=', $category_id[$g])->get();
                if (count($category_title) > 0) 
                {
                    $category_title_name.=",".$category_title[0]->category_title;
                }
            }
            $d->category_title_name = trim($category_title_name,",");
        }
        $Todo = Job::where('status',1)->paginate($this->pagination);
        foreach ($Todo as $t) 
        {
            $category_title_name = "";
            $category_id=explode(',', $t->category_id);
            for($g=0; $g<count($category_id); $g++)
            {
                $category_title = Category::where('id', '=', $category_id[$g])->get();
                if (count($category_title) > 0) 
                {
                    $category_title_name.=",".$category_title[0]->category_title;
                }
            }
            $t->category_title_name = trim($category_title_name,",");
        }
        $Inprogress = Job::where('status',2)->paginate($this->pagination);
        foreach ($Inprogress as $i) 
        {
            $category_title_name = "";
            $category_id=explode(',', $i->category_id);
            for($g=0; $g<count($category_id); $g++)
            {
                $category_title = Category::where('id', '=', $category_id[$g])->get();
                if (count($category_title) > 0) 
                {
                    $category_title_name.=",".$category_title[0]->category_title;
                }
            }
            $i->category_title_name = trim($category_title_name,",");
        }
        $Done = Job::where('status',3)->paginate($this->pagination);
        foreach ($Done as $do) 
        {
            $category_title_name = "";
            $category_id=explode(',', $do->category_id);
            for($g=0; $g<count($category_id); $g++)
            {
                $category_title = Category::where('id', '=', $category_id[$g])->get();
                if (count($category_title) > 0) 
                {
                    $category_title_name.=",".$category_title[0]->category_title;
                }
            }
            $do->category_title_name = trim($category_title_name,",");
        }
        $manager = Manager::query()->get();
        $user = User::query()->get();
        $category = Category::query()->get();
        return view('adminpanel.managejob', compact('data','task','todo','inprogress','done','Todo','Inprogress','Done','adminName','manager','user','category'));
    }

    public function search(Request $request) {
        $input = $request->all();
        $qry = Job::query(); 
        if(trim($input["search"])!="") {
            $search = $input["search"];
            $qry->where([
                ["job_title", "like", "%{$search}%"],
            ]);
        }
        $data = $qry->paginate($this->pagination);
        $data->appends($input);
        return view('adminpanel.managejob', compact('data'));
    }

    public function add() 
    {    
        $loginUserId = AUTH::user()->id;
            $admin = Admin::where('id','=',$loginUserId)->get();
            if (count($admin)>0) 
            {
                $adminName = $admin[0]->username;
               
            }
            $data1 = array(
            'Admin' => Admin::where('id','=',$loginUserId)->get(),
            'Admins' => Admin::count(),
            'Users' => User::count(),
            'Managers' => Manager::count(),
            'To do' => Job::where('status',1)->count(),
            'In progress' => Job::where('status',2)->count(),
            'Done' => Job::where('status',3)->count(),
            'Task' => Job::where('status',1)->count() + Job::where('status',2)->count() + Job::where('status',3)->count(),
        );
        $task = Job::query()->count();
        $todo = Job::where('status',1)->count();
        $inprogress = Job::where('status',2)->count();
        $done = Job::where('status',3)->count();

        $manager = Manager::query()->get();
        $user = User::query()->get();
        $category = Category::query()->get();
        $data = array('type'=>'add','category' => $category,'manager' => $manager,'data1' => $data1,'user' => $user);

        return view('adminpanel.addjob', compact('data','data1','category','manager','user','adminName','task','todo','inprogress','done'));
    }

    public function save(Request $request) {
        $input = $request->all();
        $loginUserId = AUTH::user()->id;
            $admin = Admin::where('id','=',$loginUserId)->get();
            if (count($admin)>0) 
            {
                $adminName = $admin[0]->username;
               
            }
            $data1 = array(
            'Admin' => Admin::where('id','=',$loginUserId)->get(),
            'Admins' => Admin::count(),
            'Users' => User::count(),
            'Managers' => Manager::count(),
            'To do' => Job::where('status',1)->count(),
            'In progress' => Job::where('status',2)->count(),
            'Done' => Job::where('status',3)->count(),
            'Task' => Job::where('status',1)->count() + Job::where('status',2)->count() + Job::where('status',3)->count(),
        );

        $validator=Validator::make($input,$this->getRules('Add',$input),$this->messages());
        $category = Category::query()->get();
        $manager = Manager::query()->get();
        $user = User::query()->get();

        if($validator->fails())
        {
            $data = array('type'=>'add','category' => $category,'adminName' => $adminName,'data1'=>$data1,'manager' => $manager,'user'=> $user,'input'=>$input,'error'=>$validator->messages());
            return view('adminpanel.addjob', compact('data','adminName','data1'));
            exit();
        }
        $input['manager_id'] = $input['manager_id'];
        $input['user_id'] = $input['user_id'];
        $input['category_title'] = $input['category_id'];
        $input['description'] = $input['description'];
        $input['start_time'] = $input['start_time'];
        $input['end_time'] = $input['end_time'];
        $input['status'] = 1;

        $job = Job::create($input);
        

        
        if($job->id>0) {
            return redirect()->route('adminpanel.job.manage')->with('success', 'Created successfully.');
        } else {
            return redirect()->route('adminpanel.job.add')->withErrors(['Error creating record. Please try again.']);
        }
    }
    public function edit($id) {
        $loginUserId = AUTH::user()->id;
            $admin = Admin::where('id','=',$loginUserId)->get();
            if (count($admin)>0) 
            {
                $adminName = $admin[0]->username;
               
            }
            $data1 = array(
            'Admins' => Admin::count(),
            'Users' => User::count(),
            'Managers' => Manager::count(),
            'To do' => Job::where('status',1)->count(),
            'In progress' => Job::where('status',2)->count(),
            'Done' => Job::where('status',3)->count(),
            'Task' => Job::where('status',1)->count() + Job::where('status',2)->count() + Job::where('status',3)->count(),
        );
        $task = Job::query()->count();
        $todo = Job::where('status',1)->count();
        $inprogress = Job::where('status',2)->count();
        $done = Job::where('status',3)->count();

        $how_hear_abouts = array();
        $category = Category::query()->get();
        $manager = Manager::query()->get();
        $user = User::query()->get();
        $input = Job::where('id', '=', $id)->get();
        foreach ($input as $d) 
        {
            $user_id = $d->user_id;
            $getUser = User::where('id', '=', $user_id)->get();
            if (count($getUser) > 0) 
            {
                $d->getUserName = $getUser[0]->first_name;
            }
        }        $data = array('type'=>'edit', 'input'=>$input, 'how_hear_abouts'=>$how_hear_abouts,'category' => $category,'manager' => $manager,'data1'=>$data1,'user' => $user);
        return view('adminpanel.addjob', compact('data','category','manager','user','adminName','task','todo','inprogress','done','data1'));
    }

    public function update(Request $request) {
        $input = $request->all();
        $id = $input['id'];
      

        $validator = Validator::make( $input, $this->getRules('Edit', $input), $this->messages()); 
         $manager = Manager::query()->get();
        $user = User::query()->get();
        if ($validator->fails())
        { 
            $data = array('type'=>'Edit','manager'=>$manager,'user'=>$user,'input'=>$input,'error'=>$validator->messages());
            return view('adminpanel.addchapter', compact('data'));
            exit();
        }


        $update["manager_id"] = $input['manager_id'];
        $update["user_id"] = $input['user_id'];
        $update["job_title"] = $input['job_title'];
        $update["description"] = $input['description'];
        $update["job_date"] = $input['job_date'];
        $update["start_time"] = $input['start_time'];
        $update["end_time"] = $input['end_time'];
        $update["category_id"] = $input['category_id'];
        $update["tags"] = $input['tags'];
        $update["address"] = $input['address'];
        $update["latitude"] = $input['latitude'];
        $update["longitude"] = $input['longitude'];
        $update["status"] = 1;
        
        $job = Job::where('id', '=', $id)->update($update);

        return redirect()->route('adminpanel.job.manage')->with('success', 'Updated successfully.');

    }

    public function delete($id) {
        Job::where('id','=',$id)->delete();
        return redirect()->route('adminpanel.job.manage')->with('success', 'Deleted successfully.');
    }

    public function view($id) 
    {
        //$data = Job::where('id', '=', $id)->get();
        $loginUserId = AUTH::user()->id;
            $admin = Admin::where('id','=',$loginUserId)->get();
            if (count($admin)>0) 
            {
                $adminName = $admin[0]->username;
               
            }
        $assignUser = DB::table('jobs')
            ->select('jobs.*','users.*','categories.*')
            ->join('users','jobs.user_id','users.id')
            ->join('categories','jobs.category_id','categories.id')
            ->where('jobs.id',$id)
            ->get();

        $jobimage = Jobimage::where('job_id','=',$id)->get();

        return view('adminpanel.viewjob', compact('assignUser','jobimage','adminName'));
    }

    private function getRules($type, $input) {
        $return = array();
        
        return $return;
    }

    private function messages() {
        return [
            
        ];
    }

    private function getRequiredMessage($string) {
        return 'The ' . $string . ' field is required.';
    }

    private function getGreaterMessage($string, $maxchar) {
        return 'The ' . $string . ' may not be greater than ' . $maxchar . ' characters.';
    }

    public function ajaxgetuser($id)
    {
        $arr['data'] = User::Where('manager_id','=',$id)->get(); 
        echo json_encode($arr);
    }
}

?>