<div class="top-header-main">
	<div class="top-header-menu">
		<div class="main-menu-icon">
			<a href="JavaScript:;" id="menu-icon"><span></span></a>
		</div>
		<div class="top-menu">
		</div>
		<div class="top-header-user">
			<div class="username-main">
				<a href="javascript:void(0);">Hi,
					<strong>
						<?php if(session()->has('username')): ?>
						<?php
						{
							echo $value = session('username');
						}
						?>
						<?php endif; ?>
					</strong>
				</a>
				<br>
				<?php if(session()->has('username')): ?>
					<a href="<?php echo e(url('/adminpanel/logout')); ?>"><span><i class="fas fa-sign-out-alt"></i></span>Logout</a>
				<?php endif; ?>
			</div>
			<div class="user-img">
				<a href="javascript:;" id="open-sign"><img src="<?php echo e(asset('adminpanel/images/u.png')); ?>"></a>
			</div>
			<div class="sign-out-pop">
				<a href="javascript:;" class="btn-main">Sign Out</a>
			</div>
		</div>
	</div>
</div><?php /**PATH /home/keshavvps/public_html/keshav/KG1/Chun/resources/views/adminpanel/include/header.blade.php ENDPATH**/ ?>