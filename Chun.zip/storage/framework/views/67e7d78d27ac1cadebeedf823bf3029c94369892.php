 <div class="admin-dashboard-menu-part">
                                    <ul>
                                        <li>
                                            <a href="<?php echo e(route('adminpanel.dashboard')); ?>" class="active">
                                            	<img src="<?php echo e(asset('managerpanel/images/dashboard-icn.png')); ?>">
                                            <span>DASHBOARD</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('adminpanel.user.manage')); ?>">
                                            	<img src="<?php echo e(asset('managerpanel/images/Users-icn.png')); ?>">
                                            <span>Manage Users</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('adminpanel.manager.manage')); ?>">
                                            	<img src="<?php echo e(asset('managerpanel/images/Users-icn.png')); ?>">
                                            <span>Manage Manager</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('adminpanel.category.manage')); ?>">
                                            	<img src="<?php echo e(asset('managerpanel/images/Users-icn.png')); ?>">
                                            <span>Manage Category</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('adminpanel.job.manage')); ?>">
                                            	<img src="<?php echo e(asset('managerpanel/images/Users-icn.png')); ?>">
                                            <span>Manage Job</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="admin-dashboard-messages-icn">
                                    <ul>
                                        <li>
                                            <a href="<?php echo e(route('adminpanel.logout')); ?>">
                                            	<img src="<?php echo e(asset('managerpanel/images/Users-icn.png')); ?>">
                                            <span>Logout</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div><?php /**PATH /home/keshavvps/public_html/keshav/KG1/Chun/resources/views/adminpanel/include/Sidebar.blade.php ENDPATH**/ ?>