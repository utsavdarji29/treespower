<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(config('global.sitetitle')); ?> ManagerPanel</title>
    <link href="<?php echo e(asset('adminpanel/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/slick.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/slick-theme.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/highcharts.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/fontawesome-all.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/flaticon.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" media="screen">
    <link href="<?php echo e(asset('adminpanel/css/gijgo.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/responsive.css')); ?>" rel="stylesheet">
</head>
<body>

    <div id="sitemain">

        <!-- BEGIN :: DASHBOARD -->

        <div class="dashboard-main" id="dashboard">

            

            <div class="dashboard-right-side-main">

                

                <div class="top-dashboard-title">
                    <div class="d-code-main listing-page-head-src">
                        <div class="d-title">
                            <h4><strong>Managers</strong><span>|</span><?php echo e($data->total()); ?> Total</h4>
                            <div class="input-group md-form form-sm form-2 pl-0">
                                <form method="get" action="<?php echo e(route('managerpanel.user.search')); ?>" enctype="multipart/form-data" style="display: flex;" id="search_form">
                                    <input class="form-control my-0 py-1" type="text" name="search" placeholder="Search..." aria-label="Search">
                                    <div class="input-group-append">
                                        <span class="input-group-text lighten-3" id="basic-text1"><i class="fas fa-search text-grey"
                                            aria-hidden="true"></i></span>
                                    </div>
                                </form>
                            </div>
                            <div class="filter-range-picker">
                                <!-- <div class="user-pro-detail-content-right com-input">
                                    <div class="daterange">
                                        <input id="startDate" type="text" class="form-control" name="start" placeholder="Start Date">
                                        <input id="endDate" type="text" class="form-control" name="end" placeholder="End Date">
                                    </div>
                                </div> -->
                            </div>
                        </div>
                    </div>
                    <div class="action-btn listing-page-head-btn">
                        <a href="<?php echo e(route('managerpanel.manager.add')); ?>" class="btn-main">Add Manager</a>
                    </div>
                </div>

                <div class="dashboard-content-main add-user-main listing-page-main">
                    <div class="add-user-one-main-content padding-zero">
                        <?php if(session()->has('success')): ?>
                            <div class="success-message-box">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <div class="error-message-box">                    
                                <p><?php echo e($errors->first()); ?></p>
                            </div>
                        <?php endif; ?>
                        <div class="data-table-main">
                            <table id="example" class="table table-striped table-bordered" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Image</th>
                                        <!-- <th id="th-check">
                                            <label class="custom-check-label">
                                                <input type="checkbox">
                                                <span class="checkmark"></span>
                                            </label>
                                        </th> -->
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Email</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $counter = 0; ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <?php $counter++; ?>
                                        <tr>
                                            <td><?php echo e($counter); ?>

                                            </td>
                                            <!-- <td id="td-check">
                                                <label class="custom-check-label">
                                                    <input type="checkbox">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </td> -->
                                            <td>
                                                <span class="user-name-main">
                                                <?php
                                                    $profile_picture = URL::asset('images/default-user.jpg');
                                                    if($d->userImage!="" && $d->userImage!=null) {
                                                        if(file_exists(public_path()."/uploads/userImages/".$d->userImage)) {
                                                            $profile_picture = URL::asset('uploads/userImages/'.$d->userImage);
                                                        }
                                                    }
                                                ?>
                                                <span class="bck-clr"><img src="<?php echo e($profile_picture); ?>" ></span>
                                                
                                            </td>
                                            <td>
                                                <span class="user-name-main">
                                                    <span class="user-name">
                                                        <h1><?php echo e($d->first_name); ?> </h1>
                                                    </span>
                                                </span>
                                            </td>
                                            <td>
                                                <?php echo e($d->last_name); ?>

                                            </td>
                                            <td>
                                                <?php echo e($d->email); ?>

                                            </td>
                                            <td class="dropdown-td">
                                                <a href="javascript:;" data-toggle="dropdown"><img src="<?php echo e(asset('adminpanel/images/icon.png')); ?>"></a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="<?php echo e(url('/managerpanel/edituser/'.$d->id)); ?>"><span><i class="fas fa-edit"></i></span>Edit</a>
                                                    <a class="dropdown-item" href="javascript:void(0)" onclick="confirmDelete('User', '<?php echo e(url('/managerpanel/deleteuser/'.$d->id)); ?>')"><span><i class="fas fa-trash-alt"></i></span>Delete</a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="listing-page-main-bottom">
                            <div class="listing-page-main-bottom-left">
                                <?php echo e($data->render()); ?>

                            </div>
                            <div class="listing-page-main-bottom-right">
                                <div class="listing-page-main-bottom-right-drop-down">
                                    <!-- <select class="classic arrow">
                                        <option value="1">10</option>
                                        <option value="1">10</option>
                                        <option value="1">10</option>
                                        <option value="1">10</option>
                                    </select> -->
                                </div>
                                <div class="listing-page-main-bottom-right-cnt">
                                    <p>Showing <?php echo e($data->firstItem()); ?> - <?php echo e($data->lastItem()); ?> of <?php echo e($data->total()); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php echo $__env->make('managerpanel.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>

        </div>

        <!-- END** :: DASHBOARD -->

    </div>


    <script src="<?php echo e(asset('adminpanel/js/jquery.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="<?php echo e(asset('adminpanel/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('adminpanel/js/jquery.dataTables.min.js')); ?>" charset="UTF-8"></script>
    <script type="text/javascript" src="<?php echo e(asset('adminpanel/js/dataTables.bootstrap4.min.js')); ?>" charset="UTF-8"></script>
    <script src="<?php echo e(asset('adminpanel/js/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminpanel/js/highcharts.js')); ?>"></script>
    <script src="<?php echo e(asset('adminpanel/js/gijgo.min.js')); ?>"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="<?php echo e(asset('adminpanel/js/custom.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        } );

        $('#startDate').datepicker({
            uiLibrary: 'bootstrap4'
        });
        $('#endDate').datepicker({
            uiLibrary: 'bootstrap4'
        });

    </script>
</body>
</html>
<?php echo $__env->make('managerpanel.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('managerpanel.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/keshavvps/public_html/keshav/KG1/Chun/resources/views/managerpanel/managemanager.blade.php ENDPATH**/ ?>