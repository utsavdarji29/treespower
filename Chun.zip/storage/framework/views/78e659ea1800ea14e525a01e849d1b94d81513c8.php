<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Task Details</title>
        <link rel="stylesheet" href="<?php echo e(asset('managerpanel/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('managerpanel/css/fontawesome-all.css')); ?>" >
        <link rel="stylesheet" href="<?php echo e(asset('managerpanel/css/searchboxstyle.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('managerpanel/css/slick.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('managerpanel/css/slick-theme.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('managerpanel/css/style.css')); ?>" >
        <link rel="stylesheet" href="<?php echo e(asset('managerpanel/css/responsive.css')); ?>" >
    </head>
    <body>
        <div class="main" id="main-site" style="background-image: url('<?php echo e(asset('managerpanel/images/login-bg.png')); ?>');">
            <div class="admin-dashboard">
                <div class="container">
                    <div class="admin-dashboard-main">
                        <div class="admin-dashboard-leftsidebar">
                            <div class="admin-dashboard-leftsidebar-bg-part">
                                <div class="admin-dashboard-logo">
                                    <a href="<?php echo e(route('managerpanel.dashboard')); ?>">
                                    <img src="<?php echo e(asset('managerpanel/images/Logo_img.png')); ?>">
                                    </a>
                                </div>
                                <div class="admin-dashboard-menu-part">
                                    <ul>
                                        <li>
                                            <a href="<?php echo e(route('managerpanel.dashboard')); ?>">
                                                <img src="<?php echo e(asset('managerpanel/images/dashboard-icn.png')); ?>">
                                            <span>DASHBOARD</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('managerpanel.user.manage')); ?>">
                                                <img src="<?php echo e(asset('managerpanel/images/Users-icn.png')); ?>">
                                            <span>Manage Users</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('managerpanel.category.manage')); ?>">
                                                <img src="<?php echo e(asset('managerpanel/images/Users-icn.png')); ?>">
                                            <span>Manage Category</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('managerpanel.job.manage')); ?>" class="active">
                                                <img src="<?php echo e(asset('managerpanel/images/Users-icn.png')); ?>">
                                            <span>Manage Task</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="admin-dashboard-messages-icn">
                                    <ul>
                                        <li>
                                            <a href="<?php echo e(route('managerpanel.logout')); ?>">
                                                <img src="<?php echo e(asset('managerpanel/images/Users-icn.png')); ?>">
                                            <span>Logout</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="admin-dashboard-right">
                            <div class="admin-dashboard-searchbar-part">
                                <div class="admin-dashboard-searchbar">
                                    <!-- <span class="search-icn"><img src="<?php echo e(asset('managerpanel/images/search.png')); ?>"></span>
                                    <input type="text" name="Search" placeholder="Search" class="search-sm"> -->
                                </div>
                                <div class="admin-dashboard-right-dtl">
                                    <?php echo $__env->make('managerpanel.include.Searchbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                            <div class="admin-dashboard-box-main">
                        <div class="user-details-modal-main add-users-sub-dtl">
                            <div class="user-details-sub-dtl">
                                <div class="user-details-head">
                                    <h2>Task Details:</h2>
                                    <button type="button" class="close" data-dismiss="modal"><img src="<?php echo e(asset('managerpanel/images/close-icn.png')); ?>"></button>
                                </div>
                                <div class="user-personla-dtl">
                                        <div class="add-users-form">
                                           <?php $__currentLoopData = $assignUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <table class="table table-striped table-bordered" style="width:100%">
                                <th colspan="4" align="center"><h4>View Job Users</h4></th>
                                <tr>
                                    <td width="15%"><strong>Job Title</strong></td>
                                    <td width="15%"><?php echo e($d->job_title); ?></td>
                                    <td width="15%" rowspan="3"><strong>Description</strong></td>
                                    <td width="15%" rowspan="3"><?php echo e($d->description); ?></td>
                                </tr>                       
                                <tr>
                                    <td width="15%"><strong>Job Date</strong></td>
                                    <td width="15%"><?php echo e($d->job_date); ?></td>
                                </tr>                           
                                <tr>
                                    <td width="15%"><strong>Category</strong></td>
                                    <td width="15%"><?php echo e($d->category_title); ?></td>
                                    
                                </tr>
                                <tr>
                                    <td width="15%"><strong>Address</strong></td>
                                    <td width="15%"><?php echo e($d->address); ?></td>
                                    <td width="15%"><strong>Tags</strong></td>
                                    <td width="15%"><?php echo e($d->tags); ?></td>
                                </tr>
                            </table>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <table class="table table-striped table-bordered" style="width:100%">
                                <th colspan="5" align="center"><h4>Assigned User</h4></th>
                           
                           
                                <tr>
                                    <td width="20%"><strong>User Profile</strong></td>
                                    <td width="20%"><strong>Username</strong></td>
                                    <td width="20%"><strong>Email</strong></td>
                                    <td width="20%"><strong>Phone</strong></td>
                                </tr>  
                                    <?php $__currentLoopData = $assignUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                     
                                <tr>
                                    <td>
                                        <span class="user-img-main" style="display: flex; flex-direction: row; align-items: center; justify-content: center;">
                                            <?php
                                                $profile_picture = URL::asset('images/default-user.jpg');
                                                if($d->userImage!="" && $d->userImage!=null) 
                                                {
                                                    if(file_exists(public_path()."/uploads/userImages/".$d->userImage)) 
                                                    {
                                                        $profile_picture = URL::asset('uploads/userImages/'.$d->userImage);
                                                    }
                                                }
                                            ?>
                                            <span><img src="<?php echo e($profile_picture); ?>" ></span>
                                        </span>
                                    </td>
                                    <td><?php echo e($p->first_name); ?> <?php echo e($p->last_name); ?></td>
                                    <td><?php echo e($p->email); ?></td>
                                    <td><?php echo e($p->phone); ?></td>
                                </tr>    
                                                         
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                               
                            </table>
                            <table class="table table-striped table-bordered" style="width:100%">
                                <th colspan="5" align="center"><h4>Job Images</h4></th>   
                                  
                                <tr>
                                    
                                    <?php 
                                        $i=0;
                                        ?>
                                        <?php $__currentLoopData = $jobimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        
                                            <?php
                                                if ($i%5==0) 
                                                {
                                                    echo "</tr><tr>";
                                                }
                                            ?>
                                    <td>
                                        <span class="user-img-main" style="display: flex; flex-direction: row; align-items: center; justify-content: center;">
                                            <?php
                                                $profile_picture = URL::asset('images/default-user.jpg');
                                                if($j->job_image!="" && $j->job_image!=null) 
                                                {
                                                    if(file_exists(public_path()."/uploads/userImages/".$j->job_image)) 
                                                    {
                                                        $profile_picture = URL::asset('uploads/userImages/'.$j->job_image);
                                                    }
                                                }
                                            ?>
                                            <span><img src="<?php echo e($profile_picture); ?>" height="100px" width="100px"></span>
                                        </span>
                                    </td> 
                                    <?php
                                        $i++;
                                         
                                    ?>
                                      
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                               
                            </table>
                                                <div class="add-users-fr-sec-inp">
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="add-users-fr-sec-inp">
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="add-users-fr-sec-inp">
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="add-users-fr-sec-inp">
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="add-users-fr-sec-inp">
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="add-users-fr-sec-inp">
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="add-users-sm-inp form-group">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                        <div class="user-details-footer">
                            <div class="user-details-footer-link remove-user-link">
                                <a href="javascript:;">
                                    <!-- <img src="<?php echo e(asset('managerpanel/images/delete-icn.png')); ?>">
                                    <span>REMOVE USER</span> -->
                                </a>
                            </div>
                            <div class="user-details-footer-link">
                                
                            </div>
                        </div>
                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                            </div> 
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- User Details -->
        
        
        <!-- User Details -->
        <script src="<?php echo e(asset('managerpanel/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('managerpanel/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('managerpanel/js/slick.min.js')); ?>"></script>
        <!-- <script>
            $(window).on('load', function() {
                $('#user-detailsModal').modal('show');
            });
        </script> -->
        <script type="text/javascript">
        function countryDropdown(seletor){
            var Selected = $(seletor);
            var Drop = $(seletor+'-drop');
            var DropItem = Drop.find('li');

            Selected.click(function(){
                Selected.toggleClass('open');
                Drop.toggle();
            });

            Drop.find('li').click(function(){
                Selected.removeClass('open');
                Drop.hide();
                
                var item = $(this);
                Selected.html(item.html());
            });

            DropItem.each(function(){
                var code = $(this).attr('data-code');

                if(code != undefined){
                    var countryCode = code.toLowerCase();
                    $(this).find('i').addClass('flagstrap-'+countryCode);
                }
            });
        }

        countryDropdown('#country');
    </script>
    <script type="text/javascript">
        $('.palceholder').click(function() {
          $(this).siblings('input').focus();
        });
        $('.form-control').focus(function() {
          $(this).siblings('.palceholder').hide();
        });
        $('.form-control').blur(function() {
          var $this = $(this);
          if ($this.val().length == 0)
            $(this).siblings('.palceholder').show();
        });
        $('.form-control').blur();
    </script>
    </body>
</html><?php /**PATH /home/keshavvps/public_html/keshav/KG1/Chun/resources/views/managerpanel/viewjob.blade.php ENDPATH**/ ?>