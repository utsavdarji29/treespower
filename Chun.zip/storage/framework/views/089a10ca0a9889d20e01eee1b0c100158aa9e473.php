<h4>Hi <?php echo e($adminName); ?> You are Admin</h4>
                                    <div class="admin-notification">
                                    	<!-- <img src="<?php echo e(asset('managerpanel/images/bell.png')); ?>">
                                        <span class="noti-dig">99+</span> -->
                                    </div>
                                   <!--  <div class="admin-login-pr">
                                    	<img src="<?php echo e(asset('managerpanel/images/men.png')); ?>">
                                    </div> --><?php /**PATH /home/keshavvps/public_html/keshav/KG1/Chun/resources/views/adminpanel/include/Searchbar.blade.php ENDPATH**/ ?>