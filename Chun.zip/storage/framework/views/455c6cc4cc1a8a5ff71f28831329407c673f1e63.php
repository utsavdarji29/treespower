<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Manager Dashboard</title>
        <link rel="stylesheet" href="<?php echo e(asset('managerpanel/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('managerpanel/css/fontawesome-all.css')); ?>" >
        <link rel="stylesheet" href="<?php echo e(asset('managerpanel/css/searchboxstyle.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('managerpanel/css/slick.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('managerpanel/css/slick-theme.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('managerpanel/css/style.css')); ?>" >
        <link rel="stylesheet" href="<?php echo e(asset('managerpanel/css/responsive.css')); ?>" >
    </head>
    <body>
    	<div class="main" id="main-site" style="background-image: url('<?php echo e(asset('managerpanel/images/login-bg.png')); ?>');">
            <div class="admin-dashboard manager-dashboard">
                <div class="container">
                    <div class="admin-dashboard-main">
                        <div class="admin-dashboard-leftsidebar">
                            <div class="admin-dashboard-leftsidebar-bg-part">
                                <div class="admin-dashboard-logo">
                                    <a href="<?php echo e(route('managerpanel.dashboard')); ?>">
                                    <img src="<?php echo e(asset('managerpanel/images/Logo_img.png')); ?>">
                                    </a>
                                </div>
                                <div class="admin-dashboard-menu-part">
                                    <ul>
                                        <li>
                                            <a href="<?php echo e(route('managerpanel.dashboard')); ?>" class="active">
                                                <img src="<?php echo e(asset('managerpanel/images/dashboard-icn.png')); ?>">
                                            <span>DASHBOARD</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('managerpanel.user.manage')); ?>">
                                                <img src="<?php echo e(asset('managerpanel/images/Users-icn.png')); ?>">
                                            <span>Manage Users</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('managerpanel.category.manage')); ?>">
                                                <img src="<?php echo e(asset('managerpanel/images/Users-icn.png')); ?>">
                                            <span>Manage Category</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('managerpanel.job.manage')); ?>">
                                                <img src="<?php echo e(asset('managerpanel/images/Users-icn.png')); ?>">
                                            <span>Manage Task</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="admin-dashboard-messages-icn">
                                    <ul>
                                        <li>
                                            <a href="<?php echo e(route('managerpanel.logout')); ?>">
                                                <img src="<?php echo e(asset('managerpanel/images/Users-icn.png')); ?>">
                                            <span>Logout</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="admin-dashboard-right">
                            <div class="admin-dashboard-searchbar-part">
                                <div class="admin-dashboard-searchbar">
                                    <!-- <span class="search-icn"><img src="<?php echo e(asset('managerpanel/images/search.png')); ?>"></span>
                                    <input type="text" name="Search" placeholder="Search" class="search-sm"> -->
                                </div>
                                <div class="admin-dashboard-right-dtl">
                                     <h4>Hi <?php echo e($managerName); ?> You are manager</h4>
                                    <div class="admin-notification">
                                        <!-- <img src="<?php echo e(asset('managerpanel/images/bell.png')); ?>">
                                        <span class="noti-dig">0</span> -->
                                    </div>
                                    <div class="admin-login-pr"> 
                                        <!-- <a href="<?php echo e(url('/managerpanel/editmanager/')); ?>"> -->
                                            <img src="<?php echo e($managerimage); ?>" style="max-width: 100%; max-height: 100%; width: auto; height: auto;"></a>
                                    </div>
                                    <!-- <h4>Hi <?php echo e($managerName); ?> You are manager</h4> -->
                                    <div class="admin-notification">
                                        <!-- <img src="<?php echo e(asset('managerpanel/images/bell.png')); ?>">
                                        <span class="noti-dig">0</span> -->
                                    </div>
                                    <!-- <div class="admin-login-pr">
                                        <img src="<?php echo e($managerimage); ?>" style="max-width: 100%; max-height: 100%; width: auto; height: auto;">
                                    </div> -->
                                </div>
                            </div>
                            <div class="admin-dashboard-box-main">
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <div class="admin-dashboard-sing-box">
                                        <div class="admin-dashboard-sing-box-head">
                                            <h2>USERS:</h2>
                                            <h1><?php echo e($data); ?></h1>
                                        </div>
                                        <div class="admin-dashboard-sing-box-dtl-main">
                                            <div class="admin-dashboard-sm-dtl">
                                                <h2>User:<strong><?php echo e($data); ?></strong></h2>
                                            </div>
                                            <div class="admin-dashboard-sm-dtl">
                                                <!-- <h2>Forests:<strong>4</strong></h2> -->
                                            </div>
                                        </div>
                                        <div class="admin-dashboard-sing-plus-icon">
                                            <a href="<?php echo e(route('managerpanel.user.manage')); ?>"><img src="<?php echo e(asset('managerpanel/images/plus.png')); ?>"></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <div class="admin-dashboard-sing-box">
                                        <div class="admin-dashboard-sing-box-head">
                                            <h2>Tasks:</h2>
                                            <h1><?php echo e($task); ?></h1>
                                        </div>
                                        <div class="admin-dashboard-sing-box-dtl-main">
                                            <div class="admin-dashboard-sm-dtl">
                                                <h2>To Do:<strong><?php echo e($todo); ?></strong></h2>
                                            </div>
                                            <div class="admin-dashboard-sm-dtl">
                                                <h2>In Progress:<strong><?php echo e($inprogress); ?></strong></h2>
                                            </div>
                                            <div class="admin-dashboard-sm-dtl">
                                                <h2>Done<strong><?php echo e($done); ?></strong></h2>
                                            </div>
                                        </div>
                                        <div class="admin-dashboard-sing-plus-icon">
                                            <a href="<?php echo e(route('managerpanel.job.manage')); ?>"><img src="<?php echo e(asset('managerpanel/images/plus.png')); ?>"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="<?php echo e(asset('managerpanel/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('managerpanel/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('managerpanel/js/slick.min.js')); ?>"></script>
    </body>
</html><?php /**PATH /home/keshavvps/public_html/keshav/KG1/Chun/resources/views/managerpanel/dashboard.blade.php ENDPATH**/ ?>