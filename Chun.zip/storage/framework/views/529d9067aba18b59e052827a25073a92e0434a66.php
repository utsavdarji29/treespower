<?php 
    $menu = array(
                "Dashboard" => array(
                    "icon" => "home.png", 
                    "sub" => "dashboard"
                ),
                "User Management" => array(
                    "icon" => "user.png", 
                    "sub" => array(
                        "Manage User" => "manageuser", 
                        "Add User" => "adduser"
                    )
                ),
                "Manager Management" => array(
                    "icon" => "user.png", 
                    "sub" => array(
                        "Manage Manager" => "managemanager", 
                        "Add Manager" => "addmanager"
                    )
                ),
                "Category Management" => array(
                    "icon" => "user.png", 
                    "sub" => array(
                        "Manage Category" => "managecategory", 
                        "Add Category" => "addcategory"
                    )
                ),
                "Task Management" => array(
                    "icon" => "user.png", 
                    "sub" => array(
                        "Manage Task" => "managejob", 
                        "Add Task" => "addjob"
                    )
                ),
                "Log out" => array(
                    "icon" => "home.png", 
                    "sub" => "logout"
                ),
            );
?>

<div class="sidebar-main desktop-view">
            <div class="top-logo-main">
                <img src="<?php echo e(asset('adminpanel/images/logo1.png')); ?>" class="logo-img">
                <a href="javascript:;" class="close-sidemenu"><img src="<?php echo e(asset('adminpanel/images/side.png')); ?>"></a>
            </div>

            <div class="sidebar-menu-main">
                <ul>
                    <!-- <li>
                        <a href="#">
                            <span class="m-icon"><img src="<?php echo e(URL::asset('public/images/home.png')); ?>"></span>
                            <span class="menu-text">Dashboard</span>
                        </a>
                    </li>
                    <li class="child-menu">
                        <a href="#">
                            <span class="m-icon"><img src="<?php echo e(URL::asset('public/images/user.png')); ?>"></span>
                            <span class="menu-text">User Management</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <ul class="sub-menu">
                            <li><a href="#">- User Management one</a></li>
                            <li><a href="#">- User Management two</a></li>
                        </ul>
                    </li> -->
                    <?php 
                        foreach($menu as $k => $v) { 
                            //print_r($v['sub']);
                            if(is_array($v['sub'])) {
                    ?>
                            <li class="child-menu">
                                <a href="javascript:void(0)">
                                    <span class="m-icon"><img src="<?php echo e(asset('adminpanel/images/' . $v['icon'])); ?>"></span>
                                    <span class="menu-text"><?php echo $k; ?></span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="sub-menu">
                                    <?php 
                                    foreach($v['sub'] as $k1 => $v1) {
                                    ?>
                                    <li><a href="<?php echo e(url('/managerpanel/' . $v1)); ?>">- <?php echo $k1; ?></a></li>
                                    <?php } ?>
                                </ul>
                            </li>
                    <?php
                            } else {
                    ?>
                            <li>
                                <a href="<?php echo e(url('/managerpanel/' . $v['sub'])); ?>">
                                    <span class="m-icon"><img src="<?php echo e(asset('adminpanel/images/' . $v['icon'])); ?>"></span>
                                    <span class="menu-text"><?php echo $k; ?></span>
                                </a>
                            </li>
                    <?php
                            }
                            
                        }
                    ?>
                </ul>
            </div>
        </div>

        <!-- Mobile Menu -->

        <div class="sidebar-main mobile-view">
            <div class="top-logo-main">
                <img src="<?php echo e(URL::asset('public/images/logo1.png')); ?>" class="logo-img">
                <a href="javascript:;" class="close-menu"><img src="<?php echo e(URL::asset('public/images/side.png')); ?>"></a>
            </div>

            <div class="sidebar-menu-main">
                <ul>
                    <?php 
                        foreach($menu as $k => $v) { 
                            //print_r($v['sub']);
                            if(is_array($v['sub'])) {
                    ?>
                            <li class="child-menu">
                                <a href="#">
                                    <span class="m-icon"><img src="<?php echo e(URL::asset('public/images/' . $v['icon'])); ?>"></span>
                                    <span class="menu-text"><?php echo $k; ?></span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="sub-menu">
                                    <?php 
                                    foreach($v['sub'] as $k1 => $v1) {
                                    ?>
                                    <li><a href="<?php echo e(url('/managerpanel/' . $v1)); ?>">- <?php echo $k1; ?></a></li>
                                    <?php } ?>
                                </ul>
                            </li>
                    <?php
                            } else {
                    ?>
                            <li>
                                <a href="<?php echo e(route('managerpanel.' . $v['sub'])); ?>">
                                    <span class="m-icon"><img src="<?php echo e(URL::asset('public/images/' . $v['icon'])); ?>"></span>
                                    <span class="menu-text"><?php echo $k; ?></span>
                                </a>
                            </li>
                    <?php
                            }
                            
                        }
                    ?>
                    <!-- <li>
                        <a href="#">
                            <span class="m-icon"><img src="<?php echo e(URL::asset('public/images/home.png')); ?>"></span>
                            <span class="menu-text">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <span class="m-icon"><img src="<?php echo e(URL::asset('public/images/home.png')); ?>"></span>
                            <span class="menu-text">Components</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <span class="m-icon"><img src="<?php echo e(URL::asset('public/images/home.png')); ?>"></span>
                            <span class="menu-text">Applications</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <span class="m-icon"><img src="<?php echo e(URL::asset('public/images/home.png')); ?>"></span>
                            <span class="menu-text">Custom</span>
                        </a>
                    </li>
                    <li class="child-menu">
                        <a href="#">
                            <span class="m-icon"><img src="<?php echo e(URL::asset('public/images/user.png')); ?>"></span>
                            <span class="menu-text">User Management</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <ul class="sub-menu">
                            <li><a href="#">- User Management one</a></li>
                            <li><a href="#">- User Management two</a></li>
                        </ul>
                    </li> -->
                </ul>
            </div>
        </div>

        <!-- Mobile Menu --><?php /**PATH /home/keshavvps/public_html/keshav/KG1/Chun/resources/views/managerpanel/include/sidebar.blade.php ENDPATH**/ ?>