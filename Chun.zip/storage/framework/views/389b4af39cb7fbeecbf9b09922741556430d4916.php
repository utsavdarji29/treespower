<div class="admin-dashboard-right-dtl">
                                    
                                    <h4>Hi <?php echo e($managerName); ?> You are manager</h4>
                                    <div class="admin-notification">
                                        <!-- <img src="<?php echo e(asset('managerpanel/images/bell.png')); ?>">
                                        <span class="noti-dig">0</span> -->
                                    </div>
                                    <div class="admin-login-pr">
                                        <img src="<?php echo e($managerimage); ?>" style="max-width: 100%; max-height: 100%; width: auto; height: auto;"></a>
                                    </div>
                                </div><?php /**PATH /home/keshavvps/public_html/keshav/KG1/Chun/resources/views/managerpanel/include/Searchbar.blade.php ENDPATH**/ ?>