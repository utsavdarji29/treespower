<?php

// use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('', function () {
    return redirect('/login');
})->name('index');
Route::get('/login', 'AuthController@login')->name('login');
Route::post('/login', 'AuthController@submitlogin')->name('submitlogin');
Route::get('/logout', 'AuthController@logout')->name('logout');

Route::group(['middleware' => 'auth:admin'], function(){
	//Dashboard
	Route::get('/dashboard', 'DashboardController@index')->name('dashboard');

	//USER
	Route::get('/manageuser', 'UserController@manage')->name('user.manage');
	Route::get('/adduser', 'UserController@add')->name('user.add');
	Route::post('/adduser', 'UserController@save')->name('user.save');
	Route::get('/edituser/{id}', 'UserController@edit')->name('user.edit');
	Route::post('/edituser', 'UserController@update')->name('user.update');
	Route::get('/deleteuser/{id}', 'UserController@delete')->name('user.delete');
	Route::get('/searchuser', 'UserController@search')->name('user.search');
	Route::get('/viewuser/{id}', 'UserController@view')->name('user.view');

	//Manager
	Route::get('/managemanager', 'ManagerController@manage')->name('manager.manage');
	Route::get('/addmanager', 'ManagerController@add')->name('manager.add');
	Route::post('/addmanager', 'ManagerController@save')->name('manager.save');
	Route::get('/editmanager/{id}', 'ManagerController@edit')->name('manager.edit');
	Route::post('/editmanager', 'ManagerController@update')->name('manager.update');
	Route::get('/deletemanager/{id}', 'ManagerController@delete')->name('manager.delete');
	Route::get('/searchmanager', 'ManagerController@search')->name('manager.search');

	//Category
	Route::get('/managecategory', 'CategoryController@manage')->name('category.manage');
	Route::get('/addcategory', 'CategoryController@add')->name('category.add');
	Route::post('/addcategory', 'CategoryController@save')->name('category.save');
	Route::get('/editcategory/{id}', 'CategoryController@edit')->name('category.edit');
	Route::post('/editcategory', 'CategoryController@update')->name('category.update');
	Route::get('/deletecategory/{id}', 'CategoryController@delete')->name('category.delete');
	Route::get('/searchcategory', 'CategoryController@search')->name('category.search');

	//Job
	Route::get('/managejob', 'JobController@manage')->name('job.manage');
	Route::get('/addjob', 'JobController@add')->name('job.add');
	Route::post('/addjob', 'JobController@save')->name('job.save');
	Route::get('/editjob/{id}', 'JobController@edit')->name('job.edit');
	Route::post('/editjob', 'JobController@update')->name('job.update');
	Route::get('/deletejob/{id}', 'JobController@delete')->name('job.delete');
	Route::get('/searchjob', 'JobController@search')->name('job.search');
	Route::get('/ajaxgetuser/{id}', 'JobController@ajaxgetuser')->name('job.ajaxgetuser');
	Route::get('/viewjob/{id}', 'JobController@view')->name('job.view');
});

?>